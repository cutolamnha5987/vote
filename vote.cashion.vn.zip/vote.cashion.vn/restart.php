<?php
// Đảm bảo đường dẫn chính xác tới restart.sh
$output = shell_exec('cd /vote.cashion.vn && bash restart.sh');

// Hiển thị kết quả trả về từ lệnh shell
echo "<pre>$output</pre>";

// Thông báo thành công
echo "Ứng dụng đã được rebuild và restart thành công!";
?>