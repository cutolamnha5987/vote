(() => {
var exports = {};
exports.id = 170;
exports.ids = [170];
exports.modules = {

/***/ 7758:
/***/ ((module) => {

// Exports
module.exports = {
	"container": "layout_container__k0BMw"
};


/***/ }),

/***/ 104:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1527);
/* harmony import */ var _layouts_headers_header_search_atom__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8598);
/* harmony import */ var _lib_use_is_homepage__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6338);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1377);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_i18next__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(968);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_5__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_layouts_headers_header_search_atom__WEBPACK_IMPORTED_MODULE_1__]);
_layouts_headers_header_search_atom__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];





 // Import Head component from next/head
const Header = ({ layout  })=>{
    const { t  } = (0,next_i18next__WEBPACK_IMPORTED_MODULE_3__.useTranslation)("common");
    const { show , hideHeaderSearch  } = (0,_layouts_headers_header_search_atom__WEBPACK_IMPORTED_MODULE_1__/* .useHeaderSearch */ .W)();
    const isHomePage = (0,_lib_use_is_homepage__WEBPACK_IMPORTED_MODULE_2__/* .useIsHomePage */ .M)();
    const isMultilangEnable = process.env.NEXT_PUBLIC_ENABLE_MULTI_LANG === "true" && !!process.env.NEXT_PUBLIC_AVAILABLE_LANGUAGES;
    const isFlattenHeader = (0,react__WEBPACK_IMPORTED_MODULE_4__.useMemo)(()=>!show && isHomePage && layout !== "modern", [
        show,
        isHomePage,
        layout
    ]);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_head__WEBPACK_IMPORTED_MODULE_5___default()), {
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("title", {
                    children: "Khảo s\xe1t đ\xe1nh gi\xe1 chất lượng dịch vụ tại Cashion"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                    name: "description",
                    content: ""
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                    name: "viewport",
                    content: "width=device-width, initial-scale=1"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("link", {
                    rel: "icon",
                    type: "image/x-icon",
                    href: "https://cashion.vn/wp-content/uploads/2022/12/cropped-favicon-192x192.png"
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Header);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9550:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "G": () => (/* binding */ getLayout)
/* harmony export */ });
/* unused harmony export default */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1527);
/* harmony import */ var _lib_hooks_use_layout__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7810);
/* harmony import */ var _header__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(104);
/* harmony import */ var _layout_module_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7758);
/* harmony import */ var _layout_module_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_layout_module_css__WEBPACK_IMPORTED_MODULE_3__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_header__WEBPACK_IMPORTED_MODULE_1__]);
_header__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




function SiteLayout({ children  }) {
    const { layout  } = (0,_lib_hooks_use_layout__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z)();
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: `${(_layout_module_css__WEBPACK_IMPORTED_MODULE_3___default().container)} flex min-h-screen flex-col bg-gray-100 transition-colors duration-150`,
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_header__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                layout: layout
            }),
            children
        ]
    });
}
const getLayout = (page)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(SiteLayout, {
        children: page
    });

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9378:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ SurveyForm)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1527);
/* harmony import */ var _components_SuccessMessage__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7229);
/* harmony import */ var _components_icons_check_icon__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6436);
/* harmony import */ var _components_icons_star_icon__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2369);
/* harmony import */ var _components_ui_loaders_spinner_spinner__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(102);
/* harmony import */ var _components_ui_modal_modal_context__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9021);
/* harmony import */ var _data_client_api_endpoints__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(3592);
/* harmony import */ var _lib_constants__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(9346);
/* harmony import */ var _utils_bizflycrm_util__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(2218);
/* harmony import */ var next_recaptcha_v3__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(7692);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(654);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(3590);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([next_recaptcha_v3__WEBPACK_IMPORTED_MODULE_8__, react_toastify__WEBPACK_IMPORTED_MODULE_12__]);
([next_recaptcha_v3__WEBPACK_IMPORTED_MODULE_8__, react_toastify__WEBPACK_IMPORTED_MODULE_12__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);














function SurveyForm({ id , token  }) {
    // console.log('SurveyForm id', id);
    // console.log('SurveyForm token', token);
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_10__.useRouter)();
    let OPTION_ID = id - 1;
    if (OPTION_ID >= _lib_constants__WEBPACK_IMPORTED_MODULE_13__/* .CASHION_REVIEW_OPTIONS.length */ .td.length || OPTION_ID < 0) {
        OPTION_ID = 0;
    }
    const numColumns = _lib_constants__WEBPACK_IMPORTED_MODULE_13__/* .CASHION_REVIEW_OPTIONS */ .td[OPTION_ID].length <= 4 ? 2 : 3;
    const { closeModal  } = (0,_components_ui_modal_modal_context__WEBPACK_IMPORTED_MODULE_5__/* .useModalAction */ .SO)();
    const [loading, setLoading] = (0,react__WEBPACK_IMPORTED_MODULE_11__.useState)(false);
    const [loadingVerifyPhone, setLoadingVerifyPhone] = (0,react__WEBPACK_IMPORTED_MODULE_11__.useState)(false);
    const [test, setTest] = (0,react__WEBPACK_IMPORTED_MODULE_11__.useState)(false);
    const [phoneNumber, setPhoneNumber] = (0,react__WEBPACK_IMPORTED_MODULE_11__.useState)("");
    const [rating, setRating] = (0,react__WEBPACK_IMPORTED_MODULE_11__.useState)(0);
    const [options, setOptions] = (0,react__WEBPACK_IMPORTED_MODULE_11__.useState)([]);
    const [note, setNote] = (0,react__WEBPACK_IMPORTED_MODULE_11__.useState)("");
    const [customer, setCustomer] = (0,react__WEBPACK_IMPORTED_MODULE_11__.useState)({});
    const [order, setOrder] = (0,react__WEBPACK_IMPORTED_MODULE_11__.useState)({});
    const [isSubmitted, setIsSubmitted] = (0,react__WEBPACK_IMPORTED_MODULE_11__.useState)(false); // New state variable for submission status
    const { executeRecaptcha  } = (0,next_recaptcha_v3__WEBPACK_IMPORTED_MODULE_8__.useReCaptcha)();
    const getColSpanClass = (index, length)=>{
        // return '';
        if (index !== length - 1) {
            return "";
        }
        let colSpanClass = "";
        if (index % 2 === 0) {
            colSpanClass += "col-span-2 ";
        }
        if (index % 3 === 0) {
            colSpanClass += "md:col-span-3";
        } else if (index % 3 === 1) {
            colSpanClass += "md:col-span-2";
        }
        return colSpanClass.trim();
    };
    const handleCheckboxChange = (option)=>{
        setOptions((prevOptions)=>prevOptions.includes(option) ? prevOptions.filter((opt)=>opt !== option) : [
                ...prevOptions,
                option
            ]);
    };
    const handleVerifyPhone = async ()=>{
        // console.log('Verify phone number:', phoneNumber);
        // Clear previous data
        setCustomer({});
        setOrder({});
        if (typeof phoneNumber !== "string" || phoneNumber.trim() === "") {
            console.error("Invalid phone number");
            return;
        }
        // Regular expression to check if the phone number contains only digits
        const numericRegex = /^\d+$/;
        if (!numericRegex.test(phoneNumber)) {
            console.error("Invalid phone number: phone number contains non-numeric characters");
            return;
        }
        setLoadingVerifyPhone(true);
        try {
            await fetchCustomerByPhoneNumber(phoneNumber);
        } catch (error) {
            console.error("Error fetching customer:", error);
        } finally{
            setLoadingVerifyPhone(false);
        }
    };
    const fetchCustomerByPhoneNumber = async (phone)=>{
        // console.log('Fetch customer by phone:', phone);
        // Clear previous customer data
        setCustomer({});
        if (typeof phone !== "string" || phone.trim() === "") {
            console.error("Invalid phone");
            return;
        }
        try {
            const response = await fetch(_data_client_api_endpoints__WEBPACK_IMPORTED_MODULE_6__/* .API_LOCAL_ENDPOINTS.GET_CUSTOMER */ .LI.GET_CUSTOMER, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    Authorization: `Bearer ${token}`
                },
                body: JSON.stringify({
                    phone: phone.trim(),
                    recaptchaToken: await executeRecaptcha("getCustomerByPhoneNumber")
                })
            });
            if (!response.ok) {
                throw new Error("Failed to fetch customer");
            }
            const responseData = await response.json();
            // console.log('Response customer:', responseData);
            if (responseData.total > 0) {
                setCustomer(responseData?.data[0]);
            } else {
                console.error("Phone number not found");
            }
        } catch (error) {
            console.error("Error fetching customer:", error);
        }
    };
    const submitDataVocs = async (data)=>{
        // console.log('submitDataVocs form input:', JSON.stringify(data));
        try {
            const response = await fetch(_data_client_api_endpoints__WEBPACK_IMPORTED_MODULE_6__/* .API_LOCAL_ENDPOINTS.POST_VOCS */ .LI.POST_VOCS, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    Authorization: `Bearer ${token}`
                },
                body: JSON.stringify({
                    ...data,
                    test,
                    customerId: customer?.id,
                    orderId: order?.id,
                    recaptchaToken: await executeRecaptcha("onSubmitDataVocs")
                })
            });
            if (!response.ok) {
                throw new Error("Failed to post VOCS");
            }
            const responseData = await response.json();
            // console.log('Response create VOCS:', responseData);
            return responseData;
        } catch (error) {
            console.error("Error create VOCS:", error);
        }
    };
    const handleSubmit = async (e)=>{
        e.preventDefault();
        if (!phoneNumber || phoneNumber.trim() === "" || rating === 0) {
            react_toastify__WEBPACK_IMPORTED_MODULE_12__.toast.warn("Qu\xfd kh\xe1ch vui l\xf2ng điền th\xf4ng tin");
            return;
        }
        if (!customer?.id || !order?.id) {
            react_toastify__WEBPACK_IMPORTED_MODULE_12__.toast.warn("Qu\xfd kh\xe1ch vui l\xf2ng nhập ch\xednh x\xe1c số điện thoại");
            return;
        }
        if (options.length === 0) {
            react_toastify__WEBPACK_IMPORTED_MODULE_12__.toast.warn("Qu\xfd kh\xe1ch vui l\xf2ng điền th\xf4ng tin");
            return;
        }
        setLoading(true);
        const inputData = (0,_utils_bizflycrm_util__WEBPACK_IMPORTED_MODULE_7__/* .createInputDataVocs */ .P5)({
            phone: phoneNumber.trim(),
            customer,
            order,
            rating,
            saleImproves: options,
            note
        });
        // console.log('handleSubmit inputData:', JSON.stringify(inputData));
        // return;
        try {
            let response = await submitDataVocs(inputData);
            if (response?.status === 1) {
                setIsSubmitted(true); // Set the submission status to true
            } else if (response?.status === 2) {
                console.warn("Error submitting data:", response);
                react_toastify__WEBPACK_IMPORTED_MODULE_12__.toast.warn("Q\xfay kh\xe1ch đ\xe3 đ\xe1nh gi\xe1, vui l\xf2ng quay trở lại sau");
            } else {
                console.warn("Error submitting data:", response);
                react_toastify__WEBPACK_IMPORTED_MODULE_12__.toast.warn("Lỗi kết nối. Vui l\xf2ng thử lại sau.");
            }
        } catch (error) {
            console.error("Error submitting data:", error);
        } finally{
            setLoading(false);
            closeModal();
        }
    };
    (0,react__WEBPACK_IMPORTED_MODULE_11__.useEffect)(()=>{
        if (token && customer?.id) {
            const fetchOrderByCustomerId = async (customerId)=>{
                console.log("Fetch order by customer ID:", customerId);
                setOrder({});
                if (typeof customerId !== "string" || customerId.trim() === "") {
                    console.error("Invalid customer ID");
                    return;
                }
                try {
                    const response = await fetch(_data_client_api_endpoints__WEBPACK_IMPORTED_MODULE_6__/* .API_LOCAL_ENDPOINTS.GET_ORDER */ .LI.GET_ORDER, {
                        method: "POST",
                        headers: {
                            "Content-Type": "application/json",
                            Authorization: `Bearer ${token}`
                        },
                        body: JSON.stringify({
                            customerId,
                            recaptchaToken: await executeRecaptcha("getOrderByCustomerId")
                        })
                    });
                    if (!response.ok) {
                        throw new Error("Failed to fetch order");
                    }
                    const responseData = await response.json();
                    // console.log('Response order:', responseData);
                    if (responseData.total > 0) {
                        setOrder(responseData?.data[0]);
                    } else {
                        console.error("No order found");
                    }
                // console.log(
                //   `response order code: ${responseData?.data[0]?.order_code}`
                // );
                } catch (error) {
                    console.error("Error fetching order:", error);
                }
            };
            fetchOrderByCustomerId(customer?.id);
        }
    }, [
        customer,
        executeRecaptcha,
        token
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_11__.useEffect)(()=>{
        if (router.isReady) {
            const { test  } = router.query;
            setTest(test === "true");
        }
    }, [
        router.isReady,
        router.query
    ]);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "cashion-vote-container",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: `cashion-vote-body container mx-auto py-4 md:py-8 ${isSubmitted ? "mt-8" : ""}`,
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "flex justify-center",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                        href: "https://cashion.vn",
                        target: "_blank",
                        rel: "noopener noreferrer",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_9___default()), {
                            src: "/images/logo-cashion.png",
                            alt: "Cashion Logo",
                            width: isSubmitted ? 160 : 140,
                            height: isSubmitted ? 50 : 40
                        })
                    })
                }),
                isSubmitted ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_SuccessMessage__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {}) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                    onSubmit: handleSubmit,
                    className: "max-w-2xl mx-auto px-4 py-6 md:p-8 rounded-lg",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "mb-4 md:mb-6",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                    htmlFor: "phoneNumber",
                                    className: "cashion-vote_label font-medium flex justify-center text-center",
                                    children: "Qu\xfd kh\xe1ch nhập số điện thoại để đ\xe1nh gi\xe1"
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "relative flex mt-1",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                            type: "tel",
                                            id: "phoneNumber",
                                            value: phoneNumber,
                                            onChange: (e)=>setPhoneNumber(e.target.value),
                                            onBlur: handleVerifyPhone,
                                            onTouchEnd: handleVerifyPhone,
                                            className: "placeholder-gray-400 bg-opacity-70 flex-grow px-4 py-1 md:py-2 border bg-gray-200 border-gray-400 rounded-md shadow-sm focus:ring-yellow-600 focus:border-yellow-600 text-xs md:text-md",
                                            placeholder: "Vui l\xf2ng nhập số điện thoại (*)"
                                        }),
                                        loadingVerifyPhone && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_loaders_spinner_spinner__WEBPACK_IMPORTED_MODULE_4__/* .SpinnerLoader */ .i, {
                                            className: "h-4 w-4 right-3 mt-1 md:mt-2 absolute text-green-500"
                                        }),
                                        customer?.id && order?.id && !loadingVerifyPhone && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_icons_check_icon__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                            className: "h-5 w-5 text-green-500 absolute right-3 top-1/2 -translate-y-1/2"
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "mb-4 md:mb-6",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: "cashion-vote_label font-medium flex justify-center text-center tracking-tighter",
                                    children: "Để lại đ\xe1nh gi\xe1 của Qu\xfd kh\xe1ch về chất lượng dịch vụ tại Cashion"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "flex items-center justify-center space-x-3 mt-2",
                                    children: [
                                        1,
                                        2,
                                        3,
                                        4,
                                        5
                                    ].map((star)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                            type: "button",
                                            onClick: ()=>setRating(star),
                                            className: `text-6xl appearance-none ${rating >= star ? "text-[#E07E00]" : "text-gray-200"}`,
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_icons_star_icon__WEBPACK_IMPORTED_MODULE_3__/* .StarIcon */ .r, {
                                                className: "h-10 w-10 md:h-12 md:w-12"
                                            })
                                        }, star))
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "mb-4 md:mb-6",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: "cashion-vote_label font-medium flex justify-center text-center tracking-tighter",
                                    children: "Cashion cần cải thiện điều g\xec để phục vụ Qu\xfd kh\xe1ch tốt hơn"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: `mt-2 grid grid-cols-2 md:grid-cols-${numColumns} gap-3`,
                                    children: _lib_constants__WEBPACK_IMPORTED_MODULE_13__/* .CASHION_REVIEW_OPTIONS */ .td[OPTION_ID].map((option, index, array)=>{
                                        const colSpanClass = getColSpanClass(index, array.length);
                                        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                            className: `flex items-center justify-center text-center text-xs md:text-base cursor-pointer border border-gray-400 rounded-md px-0 py-2 ${colSpanClass} ${options.includes(option) ? "text-white bg-[#E07E00]" : "text-gray-500 bg-white"}`,
                                            onClick: (e)=>{
                                                e.preventDefault(); // Prevent the default form submission behavior
                                                handleCheckboxChange(option);
                                            },
                                            children: option
                                        }, option);
                                    })
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "mb-4 md:mb-6",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                    htmlFor: "note",
                                    className: "cashion-vote_label font-medium hidden",
                                    children: "Đ\xe1nh gi\xe1 kh\xe1c về chất lượng dịch vụ tại Cashion"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("textarea", {
                                    id: "note",
                                    value: note,
                                    onChange: (e)=>setNote(e.target.value),
                                    rows: 5,
                                    className: "placeholder-gray-400 bg-opacity-70 mt-1 block w-full p-2 pl-4 md:p-3 border border-gray-400 bg-gray-200 rounded-md shadow-sm focus:ring-yellow-600 focus:border-yellow-600 text-xs md:text-sm",
                                    placeholder: "Đ\xe1nh gi\xe1 chi tiết"
                                })
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                            type: "submit",
                            disabled: loading,
                            className: "font-bold uppercase py-1 px-2 border-2 text-md rounded-md text-yellow-600 border-yellow-600 hover:bg-white hover:text-yellow-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 block mx-auto w-60",
                            children: "Gửi đ\xe1nh gi\xe1"
                        })
                    ]
                })
            ]
        })
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8598:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "W": () => (/* binding */ useHeaderSearch)
/* harmony export */ });
/* harmony import */ var jotai__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2451);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([jotai__WEBPACK_IMPORTED_MODULE_0__]);
jotai__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const headerSearchAtom = (0,jotai__WEBPACK_IMPORTED_MODULE_0__.atom)(false);
function useHeaderSearch() {
    const [headerSearch, setHeaderSearch] = (0,jotai__WEBPACK_IMPORTED_MODULE_0__.useAtom)(headerSearchAtom);
    return {
        show: headerSearch,
        toggle: ()=>setHeaderSearch(!headerSearch),
        showHeaderSearch: ()=>setHeaderSearch(true),
        hideHeaderSearch: ()=>setHeaderSearch(false)
    };
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7810:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const useLayout = ()=>{
    return {
        layout: "default"
    };
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (useLayout);


/***/ }),

/***/ 6338:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "M": () => (/* binding */ useIsHomePage)
/* harmony export */ });
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_0__);

function useIsHomePage() {
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_0__.useRouter)();
    return router.pathname === "/[[...pages]]";
}


/***/ }),

/***/ 2407:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1527);
/* harmony import */ var _components_layouts_layout__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9550);
/* harmony import */ var _components_survey_new_survey_sale__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6297);
/* harmony import */ var _components_survey_survey_form__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9378);
/* harmony import */ var _lib_constants__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(9346);
/* harmony import */ var _utils_serverSideFunctions__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(404);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react_scroll__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(3094);
/* harmony import */ var react_scroll__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_scroll__WEBPACK_IMPORTED_MODULE_7__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_layouts_layout__WEBPACK_IMPORTED_MODULE_1__, _components_survey_new_survey_sale__WEBPACK_IMPORTED_MODULE_2__, _components_survey_survey_form__WEBPACK_IMPORTED_MODULE_3__]);
([_components_layouts_layout__WEBPACK_IMPORTED_MODULE_1__, _components_survey_new_survey_sale__WEBPACK_IMPORTED_MODULE_2__, _components_survey_survey_form__WEBPACK_IMPORTED_MODULE_3__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);









// Regular expression to match 'khao-sat-[id]'
const SURVEY_PAGE_REGEX = /^khao-sat-(\d+)$/;
const getPageIndex = (pages)=>{
    if (!pages || pages.length === 0) return null;
    const match = pages[0].match(SURVEY_PAGE_REGEX);
    // console.log('match', match);
    return match ? parseInt(match[1], 10) : null;
};
const isPageIndexValid = (pageIndex)=>{
    return pageIndex !== null && pageIndex > 0 && pageIndex <= _lib_constants__WEBPACK_IMPORTED_MODULE_8__/* .CASHION_REVIEW_OPTIONS.length */ .td.length;
};
const Home = ({ token  })=>{
    const { query  } = (0,next_router__WEBPACK_IMPORTED_MODULE_5__.useRouter)();
    // const pageIndex = getPageIndex(query.pages as string[]);
    const pages = query.pages;
    const pageIndex = getPageIndex(pages);
    (0,react__WEBPACK_IMPORTED_MODULE_6__.useEffect)(()=>{
        if (query.text || query.category) {
            react_scroll__WEBPACK_IMPORTED_MODULE_7__.scroller.scrollTo("grid", {
                smooth: true,
                offset: -110
            });
        }
    }, [
        query.text,
        query.category
    ]);
    // Nếu không có pages, trả về SurveyNewSale
    if (!pages || pages.length === 0) {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_survey_new_survey_sale__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
            token: token,
            optionId: 0
        });
    }
    // Check if url is matching the SURVEY_PAGE_REGEX will show survey form
    const showSurveyComponent = isPageIndexValid(pageIndex);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: showSurveyComponent && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_survey_survey_form__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
            id: pageIndex,
            token: token
        })
    });
};
Home.getLayout = _components_layouts_layout__WEBPACK_IMPORTED_MODULE_1__/* .getLayout */ .G;
const getServerSideProps = async (context)=>{
    const pages = context.query.pages;
    const pageIndex = getPageIndex(pages);
    if (!pages || pages.length === 0 || isPageIndexValid(pageIndex)) {
        return (0,_utils_serverSideFunctions__WEBPACK_IMPORTED_MODULE_4__/* .getServerSidePropsWithToken */ .d)(context);
    }
    return {
        props: {}
    };
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Home);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9003:
/***/ ((module) => {

"use strict";
module.exports = require("classnames");

/***/ }),

/***/ 1377:
/***/ ((module) => {

"use strict";
module.exports = require("next-i18next");

/***/ }),

/***/ 5460:
/***/ ((module) => {

"use strict";
module.exports = require("next-i18next/serverSideTranslations");

/***/ }),

/***/ 3918:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 5732:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 9274:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context.js");

/***/ }),

/***/ 4486:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-blur-svg.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 9552:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-loader");

/***/ }),

/***/ 3349:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html.js");

/***/ }),

/***/ 2470:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

"use strict";
module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 3094:
/***/ ((module) => {

"use strict";
module.exports = require("react-scroll");

/***/ }),

/***/ 2451:
/***/ ((module) => {

"use strict";
module.exports = import("jotai");;

/***/ }),

/***/ 7692:
/***/ ((module) => {

"use strict";
module.exports = import("next-recaptcha-v3");;

/***/ }),

/***/ 3590:
/***/ ((module) => {

"use strict";
module.exports = import("react-toastify");;

/***/ }),

/***/ 6113:
/***/ ((module) => {

"use strict";
module.exports = require("crypto");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [527,637,295,796,127,825,231,344,297], () => (__webpack_exec__(2407)));
module.exports = __webpack_exports__;

})();