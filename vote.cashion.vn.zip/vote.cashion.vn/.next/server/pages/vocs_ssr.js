"use strict";
(() => {
var exports = {};
exports.id = 194;
exports.ids = [194];
exports.modules = {

/***/ 2539:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ vocs_ssr),
  "getServerSideProps": () => (/* reexport */ getVocsTest)
});

// EXTERNAL MODULE: ./node_modules/.pnpm/react@18.2.0/node_modules/react/jsx-runtime.js
var jsx_runtime = __webpack_require__(1527);
// EXTERNAL MODULE: ./src/data/client/api-endpoints.ts
var api_endpoints = __webpack_require__(3592);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./src/utils/token.ts
var utils_token = __webpack_require__(5770);
;// CONCATENATED MODULE: external "fs"
const external_fs_namespaceObject = require("fs");
var external_fs_default = /*#__PURE__*/__webpack_require__.n(external_fs_namespaceObject);
;// CONCATENATED MODULE: external "path"
const external_path_namespaceObject = require("path");
var external_path_default = /*#__PURE__*/__webpack_require__.n(external_path_namespaceObject);
;// CONCATENATED MODULE: ./src/data/vocs.ssr.ts



const getVocsTest = async (context)=>{
    const secretKey = process.env.SECRET_KEY;
    const token = (0,utils_token/* generateToken */.R)(secretKey);
    console.log(`secretKey: ${secretKey} | token: ${token}`);
    const filePath = external_path_default().join(process.cwd(), "data", "vocs.json");
    try {
        if (external_fs_default().existsSync(filePath)) {
            const fileContent = external_fs_default().readFileSync(filePath, "utf-8");
            const data = JSON.parse(fileContent);
            const initialData = data.map((entry)=>JSON.parse(entry));
            // console.log('initialData', JSON.stringify(initialData));
            return {
                props: {
                    initialData,
                    token
                }
            };
        } else {
            return {
                props: {
                    initialData: []
                }
            };
        }
    } catch (error) {
        console.error("Failed to fetch VOCS data:", error);
        return {
            props: {
                initialData: []
            }
        };
    }
};

;// CONCATENATED MODULE: ./src/pages/vocs_ssr/index.tsx




const VocsPage = ({ initialData , token  })=>{
    const [data, setData] = (0,external_react_.useState)(initialData);
    const handleClearAll = async ()=>{
        try {
            const res = await fetch(api_endpoints/* API_LOCAL_ENDPOINTS.TEST_CLEAR_VOCS */.LI.TEST_CLEAR_VOCS, {
                method: "DELETE",
                headers: {
                    "Content-Type": "application/json",
                    Authorization: `Bearer ${token}`
                }
            });
            if (res.ok) {
                setData([]);
            } else {
                console.error("Failed to clear VOCS data:", res.statusText);
            }
        } catch (error) {
            console.error("Failed to clear VOCS data:", error);
        }
    };
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
        className: "container mx-auto p-4",
        children: [
            /*#__PURE__*/ jsx_runtime.jsx("h1", {
                className: "text-3xl font-semibold mb-4",
                children: "VOCS Data"
            }),
            /*#__PURE__*/ jsx_runtime.jsx("div", {
                className: "mb-1",
                children: /*#__PURE__*/ jsx_runtime.jsx("button", {
                    onClick: handleClearAll,
                    className: "text-gray-900 hover:text-white border border-gray-800 hover:bg-gray-900 focus:ring-4 focus:outline-none focus:ring-gray-300 font-medium rounded-md text-xs px-3 py-1.5 text-center me-2 mb-2 dark:border-gray-600 dark:text-gray-400 dark:hover:text-white dark:hover:bg-gray-600 dark:focus:ring-gray-800",
                    children: "Clear All"
                })
            }),
            /*#__PURE__*/ jsx_runtime.jsx("div", {
                className: "overflow-x-auto",
                children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("table", {
                    className: "table-auto w-full border-collapse border border-gray-400",
                    children: [
                        /*#__PURE__*/ jsx_runtime.jsx("thead", {
                            children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("tr", {
                                className: "bg-gray-200",
                                children: [
                                    /*#__PURE__*/ jsx_runtime.jsx("th", {
                                        className: "p-2",
                                        children: "SĐT"
                                    }),
                                    /*#__PURE__*/ jsx_runtime.jsx("th", {
                                        className: "p-2",
                                        children: "Kh\xe1ch H\xe0ng"
                                    }),
                                    /*#__PURE__*/ jsx_runtime.jsx("th", {
                                        className: "p-2",
                                        children: "M\xe3 H\xf3a Đơn"
                                    }),
                                    /*#__PURE__*/ jsx_runtime.jsx("th", {
                                        className: "p-2",
                                        children: "Đ\xe1nh Gi\xe1"
                                    }),
                                    /*#__PURE__*/ jsx_runtime.jsx("th", {
                                        className: "p-2",
                                        children: "Cần Cải Thiện"
                                    }),
                                    /*#__PURE__*/ jsx_runtime.jsx("th", {
                                        className: "p-2",
                                        children: "\xdd Kiến Kh\xe1c"
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime.jsx("tbody", {
                            children: data && data.length > 0 ? data.map((entry, index)=>/*#__PURE__*/ (0,jsx_runtime.jsxs)("tr", {
                                    className: index % 2 === 0 ? "bg-gray-100" : "",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime.jsx("td", {
                                            className: "p-2 text-center",
                                            children: getFieldValue(entry, "sdt")
                                        }),
                                        /*#__PURE__*/ jsx_runtime.jsx("td", {
                                            className: "p-2 text-center",
                                            children: getFieldValue(entry, "customer")
                                        }),
                                        /*#__PURE__*/ jsx_runtime.jsx("td", {
                                            className: "p-2 text-center",
                                            children: getFieldValue(entry, "ma_hop_dong")
                                        }),
                                        /*#__PURE__*/ jsx_runtime.jsx("td", {
                                            className: "p-2 text-center",
                                            children: getFieldValue(entry, "danh_gia")
                                        }),
                                        /*#__PURE__*/ jsx_runtime.jsx("td", {
                                            className: "p-2 text-center",
                                            children: getFieldValue(entry, "can_cai_thien")
                                        }),
                                        /*#__PURE__*/ jsx_runtime.jsx("td", {
                                            className: "p-2 text-center",
                                            children: getFieldValue(entry, "danh_gia_chi_tiet")
                                        })
                                    ]
                                }, `${getFieldValue(entry, "phones")}-${index}`)) : /*#__PURE__*/ jsx_runtime.jsx("tr", {
                                children: /*#__PURE__*/ jsx_runtime.jsx("td", {
                                    colSpan: 6,
                                    className: "p-2",
                                    children: "No data available"
                                })
                            })
                        })
                    ]
                })
            })
        ]
    });
};
const getFieldValue = (entry, key)=>{
    const dataEntry = entry?.data?.[0];
    const field = dataEntry?.fields?.find((field)=>field.key === key);
    return field ? JSON.stringify(field.value) : "";
};
/* harmony default export */ const vocs_ssr = (VocsPage);


/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 6113:
/***/ ((module) => {

module.exports = require("crypto");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [527,127], () => (__webpack_exec__(2539)));
module.exports = __webpack_exports__;

})();