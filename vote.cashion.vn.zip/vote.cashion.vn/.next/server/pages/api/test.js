"use strict";
(() => {
var exports = {};
exports.id = 318;
exports.ids = [318];
exports.modules = {

/***/ 7773:
/***/ ((module) => {

module.exports = require("winston");

/***/ }),

/***/ 9648:
/***/ ((module) => {

module.exports = import("axios");;

/***/ }),

/***/ 6113:
/***/ ((module) => {

module.exports = require("crypto");

/***/ }),

/***/ 7147:
/***/ ((module) => {

module.exports = require("fs");

/***/ }),

/***/ 1017:
/***/ ((module) => {

module.exports = require("path");

/***/ }),

/***/ 6672:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _data_bizflycrm__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9368);
/* harmony import */ var _lib_applyMiddleware__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9504);
/* harmony import */ var _lib_verifyRecaptcha__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7029);
/* harmony import */ var _utils_auth_middleware__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(336);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_data_bizflycrm__WEBPACK_IMPORTED_MODULE_0__]);
_data_bizflycrm__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




const handler = async (req, res)=>{
    if (req.method === "POST") {
        const { phone  } = req.body;
        if (phone) {
            try {
                const data = await (0,_data_bizflycrm__WEBPACK_IMPORTED_MODULE_0__/* .getCustomer */ .jy)(phone);
                return res.status(200).json(data);
            } catch (error) {
                return res.status(500).json({
                    error: "Internal Server Error"
                });
            }
        } else {
            res.status(400).json({
                status: "Invalid phone number."
            });
        }
    } else {
        res.status(405).json({
            error: "Method not allowed"
        });
    }
};
// export default handler;
// export default authMiddleware(handler);
// export default applyMiddleware(verifyRecaptcha, handler);
// Handler with auth middleware
const handlerWithAuth = (0,_utils_auth_middleware__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z)(handler);
// Handler with reCAPTCHA verification
const handlerWithRecaptcha = (0,_lib_applyMiddleware__WEBPACK_IMPORTED_MODULE_2__/* .applyMiddleware */ .m)(_lib_verifyRecaptcha__WEBPACK_IMPORTED_MODULE_3__/* .verifyRecaptcha */ .Y, handler);
// Handler with both auth and reCAPTCHA verification
const handlerWithAuthAndRecaptcha = (0,_utils_auth_middleware__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z)(handlerWithRecaptcha);
// Define the exported handler based on the query parameter
const apiHandler = (req, res)=>{
    const { useCaptcha  } = req.query;
    if (useCaptcha === "true") {
        return handlerWithRecaptcha(req, res);
    } else {
        return handlerWithAuth(req, res);
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (apiHandler);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [336,368,850], () => (__webpack_exec__(6672)));
module.exports = __webpack_exports__;

})();