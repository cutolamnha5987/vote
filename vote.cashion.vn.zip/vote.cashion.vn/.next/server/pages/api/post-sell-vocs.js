"use strict";
(() => {
var exports = {};
exports.id = 574;
exports.ids = [574];
exports.modules = {

/***/ 7773:
/***/ ((module) => {

module.exports = require("winston");

/***/ }),

/***/ 9648:
/***/ ((module) => {

module.exports = import("axios");;

/***/ }),

/***/ 6113:
/***/ ((module) => {

module.exports = require("crypto");

/***/ }),

/***/ 7147:
/***/ ((module) => {

module.exports = require("fs");

/***/ }),

/***/ 1017:
/***/ ((module) => {

module.exports = require("path");

/***/ }),

/***/ 845:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _data_bizflycrm__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9368);
/* harmony import */ var _lib_applyMiddleware__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9504);
/* harmony import */ var _lib_constants__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6732);
/* harmony import */ var _lib_logger__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1019);
/* harmony import */ var _lib_verifyRecaptcha__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7029);
/* harmony import */ var _utils_auth_middleware__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(336);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_data_bizflycrm__WEBPACK_IMPORTED_MODULE_0__]);
_data_bizflycrm__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];






const handler = async (req, res)=>{
    if (req.method !== "POST") {
        return res.status(405).json({
            error: "Method Not Allowed"
        });
    }
    let inputData = req.body;
    console.log("Post VOCS body before:", JSON.stringify(inputData));
    _lib_logger__WEBPACK_IMPORTED_MODULE_1__/* ["default"].log */ .Z.log("Post VOCS body before:", inputData);
    /**
   * Verify customer ID and order ID
   */ // const { billCode, orderId } = inputData;
    // if (!billCode || !orderId) {
    //   console.error('Missing billCode or orderId');
    //   logger.error('Missing billCode or orderId');
    //   return res
    //     .status(400)
    //     .json({ status: 999, message: 'Missing billCode or orderId' });
    // }
    // Check if customer has already submitted VOCS (by orderId)
    // const lastVocs = await getLastVocByOrderId(orderId);
    // // If has already submitted VOCS (total > 0), return warning
    // if (lastVocs && lastVocs.status === 1 && lastVocs.total > 0) {
    //   console.warn(
    //     `OrderId: ${orderId} has already submitted VOCS, log_id: ${lastVocs.log_id}, vocs_id: ${lastVocs.data?.[0]?.id}`
    //   );
    //   logger.warn(
    //     `OrderId: ${orderId} has already submitted VOCS, log_id: ${lastVocs.log_id}, vocs_id: ${lastVocs.data?.[0]?.id}`
    //   );
    //   return res
    //     .status(200)
    //     .json({ status: 2, message: 'Customer has already submitted VOCS' });
    // }
    // Check if order created over 1 month ago
    // const order = await getOrderExpiredById(orderId);
    // if (order && order.status === 1 && order.total > 0) {
    //   console.warn(
    //     `Order with id: ${orderId} has expired, log_id: ${order.log_id}, order_code: ${order.data?.[0]?.order_code}`
    //   );
    //   logger.warn(
    //     `Order with id: ${orderId} has expired, log_id: ${order.log_id}, order_code: ${order.data?.[0]?.order_code}`
    //   );
    //   return res.status(200).json({ status: 3, message: 'Order has expired' });
    // }
    // Remove recaptchaToken from the body
    delete inputData.recaptchaToken;
    // Remove billCode and orderId from the body
    delete inputData.billCode;
    delete inputData.orderId;
    // Remove test from the body
    const test = inputData.test;
    delete inputData.test;
    console.log("Post VOCS body after:", JSON.stringify(inputData));
    _lib_logger__WEBPACK_IMPORTED_MODULE_1__/* ["default"].log */ .Z.log("Post VOCS body after:", inputData);
    try {
        let response;
        if (test) {
            console.log("Test mode, not send to Bizfly");
            _lib_logger__WEBPACK_IMPORTED_MODULE_1__/* ["default"].log */ .Z.log("Test mode, not send to Bizfly");
            // ~test
            response = await (0,_data_bizflycrm__WEBPACK_IMPORTED_MODULE_0__/* .postVocsTest */ .Md)(inputData);
        } else {
            // ~prod
            response = await (0,_data_bizflycrm__WEBPACK_IMPORTED_MODULE_0__/* .postVocs */ .XQ)(inputData);
        }
        return res.status(200).json(response);
    } catch (error) {
        return res.status(500).json({
            error: "Internal Server Error"
        });
    }
};
// Handler with auth middleware
const handlerWithAuth = (0,_utils_auth_middleware__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z)(handler);
// Handler with reCAPTCHA verification (without check auth token)
const handlerWithRecaptcha = (0,_lib_applyMiddleware__WEBPACK_IMPORTED_MODULE_3__/* .applyMiddleware */ .m)(_lib_verifyRecaptcha__WEBPACK_IMPORTED_MODULE_4__/* .verifyRecaptcha */ .Y, handler);
// Handler with reCAPTCHA verification and auth middleware by verify token
const handlerWithRecaptchaAndAuth = (0,_lib_applyMiddleware__WEBPACK_IMPORTED_MODULE_3__/* .applyMiddleware */ .m)(_lib_verifyRecaptcha__WEBPACK_IMPORTED_MODULE_4__/* .verifyRecaptcha */ .Y, handlerWithAuth);
// Exported handler determines the middleware to use based on the custom header
const apiHandler = (req, res)=>{
    const useOnlyAuth = req.headers[_lib_constants__WEBPACK_IMPORTED_MODULE_5__/* .USE_ONLY_AUTH_HEADER */ .qf];
    if (useOnlyAuth === "true") {
        return handlerWithAuth(req, res);
    } else {
        // Default to reCAPTCHA verification and authentication
        return handlerWithRecaptchaAndAuth(req, res);
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (apiHandler);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [336,368,850], () => (__webpack_exec__(845)));
module.exports = __webpack_exports__;

})();