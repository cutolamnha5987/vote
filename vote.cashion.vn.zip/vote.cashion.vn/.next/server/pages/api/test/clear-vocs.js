"use strict";
(() => {
var exports = {};
exports.id = 718;
exports.ids = [718];
exports.modules = {

/***/ 6113:
/***/ ((module) => {

module.exports = require("crypto");

/***/ }),

/***/ 7147:
/***/ ((module) => {

module.exports = require("fs");

/***/ }),

/***/ 1017:
/***/ ((module) => {

module.exports = require("path");

/***/ }),

/***/ 7390:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _utils_auth_middleware__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(336);
/* harmony import */ var fs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7147);
/* harmony import */ var fs__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(fs__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1017);
/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(path__WEBPACK_IMPORTED_MODULE_2__);



const handler = (req, res)=>{
    if (req.method === "DELETE") {
        try {
            const dataDir = path__WEBPACK_IMPORTED_MODULE_2___default().join(process.cwd(), "data");
            const filePath = path__WEBPACK_IMPORTED_MODULE_2___default().join(dataDir, "vocs.json");
            // Ensure the vocs.json file exists
            if (!fs__WEBPACK_IMPORTED_MODULE_1___default().existsSync(filePath)) {
                // If the file does not exist, there is nothing to clear
                return res.status(200).json({
                    message: "VOCS data is already clear"
                });
            }
            // Clear the content of the vocs.json file
            fs__WEBPACK_IMPORTED_MODULE_1___default().writeFileSync(filePath, "[]"); // Write an empty array to clear the file
            // Send a success response
            res.status(200).json({
                message: "VOCS data cleared successfully"
            });
        } catch (error) {
            console.error("Failed to clear VOCS data:", error);
            res.status(500).json({
                error: "Internal Server Error"
            });
        }
    } else {
        res.status(405).json({
            error: "Method not allowed"
        });
    }
};
// Handler without auth middleware
// const apiHandler = handler;
// Handler with auth middleware (Authorization header must be provided)
const apiHandler = (0,_utils_auth_middleware__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)(handler);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (apiHandler);


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [336], () => (__webpack_exec__(7390)));
module.exports = __webpack_exports__;

})();