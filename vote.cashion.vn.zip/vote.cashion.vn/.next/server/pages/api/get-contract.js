"use strict";
(() => {
var exports = {};
exports.id = 654;
exports.ids = [654];
exports.modules = {

/***/ 7773:
/***/ ((module) => {

module.exports = require("winston");

/***/ }),

/***/ 9648:
/***/ ((module) => {

module.exports = import("axios");;

/***/ }),

/***/ 6113:
/***/ ((module) => {

module.exports = require("crypto");

/***/ }),

/***/ 7147:
/***/ ((module) => {

module.exports = require("fs");

/***/ }),

/***/ 1017:
/***/ ((module) => {

module.exports = require("path");

/***/ }),

/***/ 9153:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _data_bizflycrm__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9368);
/* harmony import */ var _lib_applyMiddleware__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9504);
/* harmony import */ var _lib_constants__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6732);
/* harmony import */ var _lib_verifyRecaptcha__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7029);
/* harmony import */ var _utils_auth_middleware__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(336);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_data_bizflycrm__WEBPACK_IMPORTED_MODULE_0__]);
_data_bizflycrm__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];





const handler = async (req, res)=>{
    if (req.method === "POST") {
        const { customerId , contractCode  } = req.body;
        if (customerId || contractCode) {
            try {
                let data;
                if (customerId) {
                    data = await (0,_data_bizflycrm__WEBPACK_IMPORTED_MODULE_0__/* .getContractByCustomerId */ ["if"])(customerId);
                } else {
                    data = await (0,_data_bizflycrm__WEBPACK_IMPORTED_MODULE_0__/* .getContractByContractCode */ .yr)(contractCode);
                }
                return res.status(200).json(data);
            } catch (error) {
                return res.status(500).json({
                    error: "Internal Server Error"
                });
            }
        } else {
            res.status(400).json({
                status: "Invalid customer ID."
            });
        }
    } else {
        res.status(405).json({
            error: "Method not allowed"
        });
    }
};
// Handler secured with authentication middleware (verifies auth token)
const handlerWithAuth = (0,_utils_auth_middleware__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z)(handler);
// Handler secured with reCAPTCHA verification (does not check auth token)
const handlerWithRecaptcha = (0,_lib_applyMiddleware__WEBPACK_IMPORTED_MODULE_2__/* .applyMiddleware */ .m)(_lib_verifyRecaptcha__WEBPACK_IMPORTED_MODULE_3__/* .verifyRecaptcha */ .Y, handler);
// Handler secured with both reCAPTCHA verification and authentication middleware (verifies auth token)
const handlerWithRecaptchaAndAuth = (0,_lib_applyMiddleware__WEBPACK_IMPORTED_MODULE_2__/* .applyMiddleware */ .m)(_lib_verifyRecaptcha__WEBPACK_IMPORTED_MODULE_3__/* .verifyRecaptcha */ .Y, handlerWithAuth);
// Exported handler determines the middleware to use based on the custom header
const apiHandler = (req, res)=>{
    const useOnlyAuth = req.headers[_lib_constants__WEBPACK_IMPORTED_MODULE_4__/* .USE_ONLY_AUTH_HEADER */ .qf];
    if (useOnlyAuth === "true") {
        return handlerWithAuth(req, res);
    } else {
        // Default to reCAPTCHA verification and authentication
        return handlerWithRecaptchaAndAuth(req, res);
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (apiHandler);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [336,368,850], () => (__webpack_exec__(9153)));
module.exports = __webpack_exports__;

})();