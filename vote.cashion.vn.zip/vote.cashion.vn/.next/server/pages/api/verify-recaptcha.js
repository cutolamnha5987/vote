"use strict";
(() => {
var exports = {};
exports.id = 235;
exports.ids = [235];
exports.modules = {

/***/ 9530:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
async function handler(req, res) {
    if (req.method === "POST") {
        const { recaptchaToken  } = req.body;
        console.log("recaptchaToken:", recaptchaToken);
        if (!recaptchaToken) {
            return res.status(400).json({
                success: false,
                message: "reCAPTCHA token is missing"
            });
        }
        const response = await fetch(`https://www.google.com/recaptcha/api/siteverify`, {
            method: "POST",
            headers: {
                "Content-Type": "application/x-www-form-urlencoded"
            },
            body: `secret=${process.env.RECAPTCHA_SECRET_KEY}&response=${recaptchaToken}`
        });
        const data = await response.json();
        if (data.success) {
            // Handle successful verification and form submission (e.g., send email)
            res.status(200).json({
                success: true
            });
        } else {
            res.status(400).json({
                success: false
            });
        }
    } else {
        res.status(405).json({
            success: false,
            message: "Method not allowed"
        });
    }
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(9530));
module.exports = __webpack_exports__;

})();