"use strict";
(() => {
var exports = {};
exports.id = 792;
exports.ids = [792];
exports.modules = {

/***/ 4142:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1527);
/* harmony import */ var _data_client_api_endpoints__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3592);
/* harmony import */ var _utils_serverSideFunctions__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(404);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);




const VocsPage = ({ token  })=>{
    const [data, setData] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)([]);
    const handleClearAll = async ()=>{
        try {
            const res = await fetch(_data_client_api_endpoints__WEBPACK_IMPORTED_MODULE_1__/* .API_LOCAL_ENDPOINTS.TEST_CLEAR_VOCS */ .LI.TEST_CLEAR_VOCS, {
                method: "DELETE",
                headers: {
                    "Content-Type": "application/json",
                    Authorization: `Bearer ${token}`
                }
            });
            if (res.ok) {
                setData([]);
            } else {
                console.error("Failed to clear VOCS data:", res.statusText);
            }
        } catch (error) {
            console.error("Failed to clear VOCS data:", error);
        }
    };
    (0,react__WEBPACK_IMPORTED_MODULE_3__.useEffect)(()=>{
        const fetchData = async ()=>{
            try {
                const res = await fetch(_data_client_api_endpoints__WEBPACK_IMPORTED_MODULE_1__/* .API_LOCAL_ENDPOINTS.TEST_GET_VOCS */ .LI.TEST_GET_VOCS, {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json",
                        Authorization: `Bearer ${token}`
                    }
                });
                const rawData = await res.json();
                const parsedData = rawData.map((entry)=>JSON.parse(entry));
                setData(parsedData);
            } catch (error) {
                console.error("Failed to fetch VOCS data:", error);
            }
        };
        fetchData();
    }, [
        token
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "container mx-auto p-4",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                className: "text-3xl font-semibold mb-4",
                children: "VOCS Data"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "mb-1",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                    onClick: handleClearAll,
                    className: "text-gray-900 hover:text-white border border-gray-800 hover:bg-gray-900 focus:ring-4 focus:outline-none focus:ring-gray-300 font-medium rounded-md text-xs px-3 py-1.5 text-center me-2 mb-2 dark:border-gray-600 dark:text-gray-400 dark:hover:text-white dark:hover:bg-gray-600 dark:focus:ring-gray-800",
                    children: "Clear All"
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "overflow-x-auto",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("table", {
                    className: "table-auto w-full border-collapse border border-gray-400",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("thead", {
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                className: "bg-gray-200",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                        className: "p-2",
                                        children: "SĐT"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                        className: "p-2",
                                        children: "Kh\xe1ch H\xe0ng"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                        className: "p-2",
                                        children: "M\xe3 H\xf3a Đơn"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                        className: "p-2",
                                        children: "Đ\xe1nh Gi\xe1"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                        className: "p-2",
                                        children: "Cần Cải Thiện"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                        className: "p-2",
                                        children: "\xdd Kiến Kh\xe1c"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                        className: "p-2",
                                        children: "Giới Thiệu"
                                    }),
                                    " "
                                ]
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("tbody", {
                            children: data && data.length > 0 ? data.map((entry, index)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                    className: index % 2 === 0 ? "bg-gray-100" : "",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                            className: "p-2 text-center",
                                            children: getFieldValue(entry, "sdt")
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                            className: "p-2 text-center",
                                            children: getFieldValue(entry, "customer")
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                            className: "p-2 text-center",
                                            children: getFieldValue(entry, "ma_hoa_don")
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                            className: "p-2 text-center",
                                            children: getFieldValue(entry, "danh_gia")
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                            className: "p-2 text-center",
                                            children: getFieldValue(entry, "can_cai_thien")
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                            className: "p-2 text-center",
                                            children: getFieldValue(entry, "danh_gia_chi_tiet")
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("td", {
                                            className: "p-2 text-center",
                                            children: [
                                                getFieldValue(entry, "ref"),
                                                " "
                                            ]
                                        })
                                    ]
                                }, `${getFieldValue(entry, "phones")}-${index}`)) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("tr", {
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                    colSpan: 7,
                                    className: "p-2",
                                    children: "No data available"
                                })
                            })
                        })
                    ]
                })
            })
        ]
    });
};
const getFieldValue = (entry, key)=>{
    const dataEntry = entry?.data?.[0];
    const field = dataEntry?.fields?.find((field)=>field.key === key);
    return field ? JSON.stringify(field.value) : "";
};
const getServerSideProps = _utils_serverSideFunctions__WEBPACK_IMPORTED_MODULE_2__/* .getServerSidePropsWithToken */ .d;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (VocsPage);


/***/ }),

/***/ 404:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "d": () => (/* binding */ getServerSidePropsWithToken)
/* harmony export */ });
/* harmony import */ var next_i18next_serverSideTranslations__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5460);
/* harmony import */ var next_i18next_serverSideTranslations__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_i18next_serverSideTranslations__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _token__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5770);


const getServerSidePropsWithToken = async ({ locale , params  })=>{
    // console.log('locale', locale);
    // console.log('params', params);
    const secretKey = process.env.SECRET_KEY;
    const token = (0,_token__WEBPACK_IMPORTED_MODULE_1__/* .generateToken */ .R)(secretKey);
    console.log(`secretKey: ${secretKey} | token: ${token}`);
    return {
        props: {
            token,
            ...await (0,next_i18next_serverSideTranslations__WEBPACK_IMPORTED_MODULE_0__.serverSideTranslations)(locale, [
                "common",
                "faq"
            ])
        }
    };
};


/***/ }),

/***/ 5460:
/***/ ((module) => {

module.exports = require("next-i18next/serverSideTranslations");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 6113:
/***/ ((module) => {

module.exports = require("crypto");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [527,127], () => (__webpack_exec__(4142)));
module.exports = __webpack_exports__;

})();