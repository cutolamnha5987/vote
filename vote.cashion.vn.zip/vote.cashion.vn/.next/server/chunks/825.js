"use strict";
exports.id = 825;
exports.ids = [825];
exports.modules = {

/***/ 9021:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DY": () => (/* binding */ ModalProvider),
/* harmony export */   "SO": () => (/* binding */ useModalAction),
/* harmony export */   "X9": () => (/* binding */ useModalState)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1527);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


const initialState = {
    view: undefined,
    isOpen: false,
    data: null
};
function modalReducer(state, action) {
    switch(action.type){
        case "open":
            return {
                ...state,
                view: action.view,
                data: action.payload,
                isOpen: true
            };
        case "close":
            return {
                ...state,
                view: undefined,
                data: null,
                isOpen: false
            };
        default:
            throw new Error("Unknown Modal Action!");
    }
}
const ModalStateContext = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().createContext(initialState);
ModalStateContext.displayName = "ModalStateContext";
const ModalActionContext = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().createContext(undefined);
ModalActionContext.displayName = "ModalActionContext";
const ModalProvider = ({ children  })=>{
    const [state, dispatch] = react__WEBPACK_IMPORTED_MODULE_1___default().useReducer(modalReducer, initialState);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(ModalStateContext.Provider, {
        value: state,
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(ModalActionContext.Provider, {
            value: dispatch,
            children: children
        })
    });
};
function useModalState() {
    const context = react__WEBPACK_IMPORTED_MODULE_1___default().useContext(ModalStateContext);
    if (context === undefined) {
        throw new Error(`useModalState must be used within a ModalProvider`);
    }
    return context;
}
function useModalAction() {
    const dispatch = react__WEBPACK_IMPORTED_MODULE_1___default().useContext(ModalActionContext);
    if (dispatch === undefined) {
        throw new Error(`useModalAction must be used within a ModalProvider`);
    }
    return {
        openModal (view, payload) {
            dispatch({
                type: "open",
                view,
                payload
            });
        },
        closeModal () {
            dispatch({
                type: "close"
            });
        }
    };
}


/***/ }),

/***/ 9346:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Mg": () => (/* binding */ getDirection),
/* harmony export */   "bZ": () => (/* binding */ CASHION_SURVEY_SALE_OPTIONS),
/* harmony export */   "td": () => (/* binding */ CASHION_REVIEW_OPTIONS)
/* harmony export */ });
/* unused harmony exports TOKEN, AUTH_TOKEN_KEY, AUTH_PERMISSIONS, LIMIT, RTL_LANGUAGES, USE_ONLY_AUTH_HEADER, CASHION_VOC_TIME_DELAY_IN_MILLISECONDS, CASHION_ORDER_TIME_EXPIRATION_IN_MILLISECONDS */
const TOKEN = "token";
const AUTH_TOKEN_KEY = "auth_token";
const AUTH_PERMISSIONS = "auth_permissions";
const LIMIT = 10;
const RTL_LANGUAGES = [
    "ar",
    "he"
];
function getDirection(language) {
    if (!language) return "ltr";
    return RTL_LANGUAGES.includes(language) ? "rtl" : "ltr";
}
// For test bypass ReCAPTCHA (ex: test localhost on mobile)
const USE_ONLY_AUTH_HEADER = "x-use-only-auth";
const CASHION_VOC_TIME_DELAY_IN_MILLISECONDS = (/* unused pure expression or super */ null && (3 * 60 * 1000)); // 3 minutes
const CASHION_ORDER_TIME_EXPIRATION_IN_MILLISECONDS = (/* unused pure expression or super */ null && (30 * 24 * 60 * 60 * 1000)); // 30 days
const CASHION_REVIEW_OPTIONS = [
    [
        "Sản phẩm",
        "Tư vấn vi\xean",
        "Thời gian giao h\xe0ng",
        "Đ\xf3ng g\xf3i sản phẩm",
        "Chương tr\xecnh khuyến m\xe3i",
        "Kh\xf4ng gian cửa h\xe0ng",
        "Ch\xednh s\xe1ch hậu m\xe3i",
        "Kh\xe1c"
    ],
    [
        "Thời gian giao dịch",
        "Tư vấn vi\xean",
        "Kh\xf4ng gian cửa h\xe0ng",
        "Quy tr\xecnh v\xe0 ch\xednh s\xe1ch",
        "Chương tr\xecnh khuyến m\xe3i",
        "Kh\xe1c"
    ],
    [
        "Sản phẩm",
        "Tư vấn vi\xean",
        "Thời gian giao h\xe0ng",
        "Đ\xf3ng g\xf3i sản phẩm",
        "Chương tr\xecnh khuyến m\xe3i",
        "Kh\xf4ng gian cửa h\xe0ng",
        "Kh\xe1c"
    ]
];
const CASHION_SURVEY_SALE_OPTIONS = [
    [
        "Kh\xf4ng c\xf2n nhu cầu",
        "Gi\xe1 th\xe0nh sản phẩm",
        "Nh\xe2n vi\xean tư vấn",
        "Ch\xednh s\xe1ch thu hồi",
        "Kh\xf4ng kịp thời tư vấn",
        "Thời gian giao h\xe0ng",
        "Chưa c\xf3 sản phẩm ph\xf9 hợp",
        "Kh\xe1c"
    ],
    [
        "Kh\xf4ng c\xf2n nhu cầu",
        "Kh\xf4ng đ\xe1p ứng gi\xe1",
        "Nh\xe2n vi\xean tư vấn",
        "Kh\xf4ng đồng \xfd quy tr\xecnh",
        "Kh\xf4ng kịp thời tư vấn",
        "Thời gian giao dịch",
        "Kh\xe1c"
    ]
];


/***/ })

};
;