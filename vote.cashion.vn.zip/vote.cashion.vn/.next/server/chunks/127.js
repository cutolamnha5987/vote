"use strict";
exports.id = 127;
exports.ids = [127];
exports.modules = {

/***/ 3592:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LI": () => (/* binding */ API_LOCAL_ENDPOINTS),
/* harmony export */   "aW": () => (/* binding */ BIZFLY_CRM_TABLES)
/* harmony export */ });
/* unused harmony exports BASE_URL, API_ENDPOINTS, BIZFLY_CRM_QUERY_PARAMS */
const BASE_URL = process.env.BIZFLY_CRM_REST_API_ENDPOINT;
const API_ENDPOINTS = {
    BASE_TABLE_STRUCT: "/_api/base-table/struct",
    BASE_TABLE_FIND: "/_api/base-table/find",
    BASE_TABLE_UPDATE: "/_api/base-table/update"
};
const API_LOCAL_ENDPOINTS = {
    GENERATE_TOKEN: "/api/generate-token",
    VERIFY_RECAPTCHA: "/api/verify-recaptcha",
    GET_CUSTOMER: "/api/get-customer",
    GET_CONTRACT: "/api/get-contract",
    GET_ORDER: "/api/get-order",
    POST_VOCS: "/api/post-vocs",
    POST_SELL_VOCS: "/api/post-sell-vocs",
    POST_PURCHASE_VOCS: "/api/post-purchase-vocs",
    // Test save vocs to local storage
    TEST_SAVE_VOCS: "/api/test/save-vocs",
    TEST_GET_VOCS: "/api/test/get-vocs",
    TEST_CLEAR_VOCS: "/api/test/clear-vocs"
};
const BIZFLY_CRM_TABLES = {
    CUSTOMER: "data_customer",
    CONTRACT: "data_contract",
    ORDER: "data_order",
    VOCS: "data_extra_4"
};
const BIZFLY_CRM_QUERY_PARAMS = {
    SORTED_ASC: "asc",
    SORTED_DESC: "desc",
    OUTPUT: "by-key",
    LIMIT: 1
};


/***/ }),

/***/ 5770:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "R": () => (/* binding */ generateToken)
/* harmony export */ });
/* unused harmony export verifyToken */
/* harmony import */ var crypto__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6113);
/* harmony import */ var crypto__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(crypto__WEBPACK_IMPORTED_MODULE_0__);
// utils/token.ts

const generateToken = (secretKey)=>{
    const original = crypto__WEBPACK_IMPORTED_MODULE_0___default().randomBytes(16).toString("hex");
    const timestamp = Date.now(); // current time in milliseconds
    const hash = crypto__WEBPACK_IMPORTED_MODULE_0___default().createHmac("sha256", secretKey).update(`${original}:${timestamp}`).digest("hex");
    return `${hash}:${original}:${timestamp}`;
};
const verifyToken = (token, secretKey)=>{
    const [hash, original, timestamp] = token.split(":");
    if (!hash || !original || !timestamp) {
        return false;
    }
    const currentTimestamp = Date.now();
    const tokenTimestamp = parseInt(timestamp, 10);
    // Check if the token is older than 1 hour (3600000 milliseconds)
    if (currentTimestamp - tokenTimestamp > 3600000) {
        return false;
    }
    const expectedHash = crypto.createHmac("sha256", secretKey).update(`${original}:${timestamp}`).digest("hex");
    return hash === expectedHash;
};


/***/ })

};
;