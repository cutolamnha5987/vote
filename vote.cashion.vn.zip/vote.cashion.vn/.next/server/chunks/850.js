"use strict";
exports.id = 850;
exports.ids = [850];
exports.modules = {

/***/ 9504:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "m": () => (/* binding */ applyMiddleware)
/* harmony export */ });
// lib/applyMiddleware.ts
function applyMiddleware(middleware, handler) {
    return (req, res)=>{
        middleware(req, res, ()=>{
            handler(req, res);
        });
    };
}


/***/ }),

/***/ 7029:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Y": () => (/* binding */ verifyRecaptcha)
/* harmony export */ });
async function verifyRecaptcha(req, res, next) {
    const { recaptchaToken  } = req.body;
    console.log("recaptchaToken:", recaptchaToken);
    if (!recaptchaToken) {
        return res.status(400).json({
            success: false,
            message: "reCAPTCHA token is missing"
        });
    }
    const response = await fetch(`https://www.google.com/recaptcha/api/siteverify`, {
        method: "POST",
        headers: {
            "Content-Type": "application/x-www-form-urlencoded"
        },
        body: `secret=${process.env.RECAPTCHA_SECRET_KEY}&response=${recaptchaToken}`
    });
    const data = await response.json();
    if (!data.success) {
        return res.status(400).json({
            success: false,
            message: "reCAPTCHA verification failed"
        });
    }
    next();
}


/***/ })

};
;