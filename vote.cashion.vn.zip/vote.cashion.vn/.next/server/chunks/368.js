"use strict";
exports.id = 368;
exports.ids = [368];
exports.modules = {

/***/ 9368:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Ai": () => (/* binding */ getLastVocByCustomer),
/* harmony export */   "Md": () => (/* binding */ postVocsTest),
/* harmony export */   "Pf": () => (/* binding */ getVocsDataFromFile),
/* harmony export */   "WF": () => (/* binding */ getOrderByCustomerId),
/* harmony export */   "XQ": () => (/* binding */ postVocs),
/* harmony export */   "de": () => (/* binding */ saveVocsDataToFile),
/* harmony export */   "if": () => (/* binding */ getContractByCustomerId),
/* harmony export */   "jy": () => (/* binding */ getCustomer),
/* harmony export */   "yr": () => (/* binding */ getContractByContractCode)
/* harmony export */ });
/* unused harmony exports generateHeaders, getOrderExpiredById, getLastVocByOrderId */
/* harmony import */ var _lib_logger__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1019);
/* harmony import */ var _utils_bizflycrm_util__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(599);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9648);
/* harmony import */ var crypto__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6113);
/* harmony import */ var crypto__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(crypto__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var fs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7147);
/* harmony import */ var fs__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(fs__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1017);
/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(path__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _client_api_endpoints__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(4780);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_2__]);
axios__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];







// console.log(
//   `BIZFLY_CRM_REST_API_ENDPOINT=${process.env.BIZFLY_CRM_REST_API_ENDPOINT}`
// );
// console.log(`BIZFLY_CRM_PROJECT_TOKEN=${process.env.BIZFLY_CRM_PROJECT_TOKEN}`);
// console.log(`BIZFLY_CRM_API_KEY=${process.env.BIZFLY_CRM_API_KEY}`);
// console.log(
//   `BIZFLY_CRM_API_SECRET_KEY=${process.env.BIZFLY_CRM_API_SECRET_KEY}`
// );
function generateHmacHash(timestamp, projectToken, apiSecret) {
    // console.log(
    //   `timestamp: ${timestamp}, projectToken: ${projectToken}, apiSecret: ${apiSecret}`
    // );
    // Concatenate timeNow and projectToken
    const data = timestamp + projectToken;
    // Create HMAC SHA-512 hash
    const hmac = (0,crypto__WEBPACK_IMPORTED_MODULE_3__.createHmac)("sha512", apiSecret);
    hmac.update(data);
    // Return the generated hash in hexadecimal format
    return hmac.digest("hex");
}
function generateHeaders() {
    const timeNow = new Date().getTime().toString();
    const headers = {
        "Content-Type": "application/json",
        "cb-access-key": process.env.BIZFLY_CRM_API_KEY,
        "cb-project-token": process.env.BIZFLY_CRM_PROJECT_TOKEN,
        "cb-access-timestamp": timeNow,
        "cb-access-sign": generateHmacHash(timeNow, process.env.BIZFLY_CRM_PROJECT_TOKEN, process.env.BIZFLY_CRM_API_SECRET_KEY)
    };
    return headers;
}
const getCustomer = async (phone, sort = _client_api_endpoints__WEBPACK_IMPORTED_MODULE_6__/* .BIZFLY_CRM_QUERY_PARAMS.SORTED_DESC */ .rB.SORTED_DESC)=>{
    try {
        const url = _client_api_endpoints__WEBPACK_IMPORTED_MODULE_6__/* .BASE_URL */ ._n + _client_api_endpoints__WEBPACK_IMPORTED_MODULE_6__/* .API_ENDPOINTS.BASE_TABLE_FIND */ .Pn.BASE_TABLE_FIND;
        const headers = generateHeaders();
        const body = {
            table: _client_api_endpoints__WEBPACK_IMPORTED_MODULE_6__/* .BIZFLY_CRM_TABLES.CUSTOMER */ .aW.CUSTOMER,
            limit: _client_api_endpoints__WEBPACK_IMPORTED_MODULE_6__/* .BIZFLY_CRM_QUERY_PARAMS.LIMIT */ .rB.LIMIT,
            sort: {
                _id: sort === _client_api_endpoints__WEBPACK_IMPORTED_MODULE_6__/* .BIZFLY_CRM_QUERY_PARAMS.SORTED_DESC */ .rB.SORTED_DESC ? -1 : 1
            },
            output: _client_api_endpoints__WEBPACK_IMPORTED_MODULE_6__/* .BIZFLY_CRM_QUERY_PARAMS.OUTPUT */ .rB.OUTPUT,
            query: {
                "phones.value": phone
            }
        };
        // Log request details
        console.log("Request URL:", url);
        console.log("Request Headers:", headers);
        console.log("Request Body:", body);
        _lib_logger__WEBPACK_IMPORTED_MODULE_0__/* ["default"].log */ .Z.log("Request URL:", url);
        _lib_logger__WEBPACK_IMPORTED_MODULE_0__/* ["default"].log */ .Z.log("Request Headers:", headers);
        _lib_logger__WEBPACK_IMPORTED_MODULE_0__/* ["default"].log */ .Z.log("Request Body:", body);
        const response = await axios__WEBPACK_IMPORTED_MODULE_2__["default"].post(url, body, {
            headers: headers
        });
        // Log the response
        console.log("Response Status:", response.status);
        console.log("Response Data:", response.data);
        _lib_logger__WEBPACK_IMPORTED_MODULE_0__/* ["default"].log */ .Z.log("Response Status:", response.status);
        _lib_logger__WEBPACK_IMPORTED_MODULE_0__/* ["default"].log */ .Z.log("Response Data:", response.data);
        return response.data;
    } catch (error) {
        _lib_logger__WEBPACK_IMPORTED_MODULE_0__/* ["default"].error */ .Z.error(`Error getting customer by phone: ${phone}`, error);
        throw new Error(`Error getting customer by phone: ${phone}`);
    }
};
const getContractByCustomerId = async (customerId, sort = _client_api_endpoints__WEBPACK_IMPORTED_MODULE_6__/* .BIZFLY_CRM_QUERY_PARAMS.SORTED_DESC */ .rB.SORTED_DESC)=>{
    try {
        const url = _client_api_endpoints__WEBPACK_IMPORTED_MODULE_6__/* .BASE_URL */ ._n + _client_api_endpoints__WEBPACK_IMPORTED_MODULE_6__/* .API_ENDPOINTS.BASE_TABLE_FIND */ .Pn.BASE_TABLE_FIND;
        const headers = generateHeaders();
        const body = {
            table: _client_api_endpoints__WEBPACK_IMPORTED_MODULE_6__/* .BIZFLY_CRM_TABLES.CONTRACT */ .aW.CONTRACT,
            limit: _client_api_endpoints__WEBPACK_IMPORTED_MODULE_6__/* .BIZFLY_CRM_QUERY_PARAMS.LIMIT */ .rB.LIMIT,
            sort: {
                _id: sort === _client_api_endpoints__WEBPACK_IMPORTED_MODULE_6__/* .BIZFLY_CRM_QUERY_PARAMS.SORTED_DESC */ .rB.SORTED_DESC ? -1 : 1
            },
            output: _client_api_endpoints__WEBPACK_IMPORTED_MODULE_6__/* .BIZFLY_CRM_QUERY_PARAMS.OUTPUT */ .rB.OUTPUT,
            query: {
                "customer.id": customerId
            }
        };
        // Log request details
        console.log("Request URL:", url);
        console.log("Request Headers:", headers);
        console.log("Request Body:", body);
        _lib_logger__WEBPACK_IMPORTED_MODULE_0__/* ["default"].log */ .Z.log("Request URL:", url);
        _lib_logger__WEBPACK_IMPORTED_MODULE_0__/* ["default"].log */ .Z.log("Request Headers:", headers);
        _lib_logger__WEBPACK_IMPORTED_MODULE_0__/* ["default"].log */ .Z.log("Request Body:", body);
        const response = await axios__WEBPACK_IMPORTED_MODULE_2__["default"].post(url, body, {
            headers: headers
        });
        // Log the response
        console.log("Response Status:", response.status);
        console.log("Response Data:", response.data);
        _lib_logger__WEBPACK_IMPORTED_MODULE_0__/* ["default"].log */ .Z.log("Response Status:", response.status);
        _lib_logger__WEBPACK_IMPORTED_MODULE_0__/* ["default"].log */ .Z.log("Response Data:", response.data);
        return response.data;
    } catch (error) {
        _lib_logger__WEBPACK_IMPORTED_MODULE_0__/* ["default"].error */ .Z.error(`Error getting contract by customerId: ${customerId}`, error);
        throw new Error(`Error getting contract by customerId: ${customerId}`);
    }
};
const getContractByContractCode = async (contractCode, sort = _client_api_endpoints__WEBPACK_IMPORTED_MODULE_6__/* .BIZFLY_CRM_QUERY_PARAMS.SORTED_DESC */ .rB.SORTED_DESC)=>{
    try {
        const url = _client_api_endpoints__WEBPACK_IMPORTED_MODULE_6__/* .BASE_URL */ ._n + _client_api_endpoints__WEBPACK_IMPORTED_MODULE_6__/* .API_ENDPOINTS.BASE_TABLE_FIND */ .Pn.BASE_TABLE_FIND;
        const headers = generateHeaders();
        const body = {
            table: _client_api_endpoints__WEBPACK_IMPORTED_MODULE_6__/* .BIZFLY_CRM_TABLES.CONTRACT */ .aW.CONTRACT,
            limit: _client_api_endpoints__WEBPACK_IMPORTED_MODULE_6__/* .BIZFLY_CRM_QUERY_PARAMS.LIMIT */ .rB.LIMIT,
            sort: {
                _id: sort === _client_api_endpoints__WEBPACK_IMPORTED_MODULE_6__/* .BIZFLY_CRM_QUERY_PARAMS.SORTED_DESC */ .rB.SORTED_DESC ? -1 : 1
            },
            output: _client_api_endpoints__WEBPACK_IMPORTED_MODULE_6__/* .BIZFLY_CRM_QUERY_PARAMS.OUTPUT */ .rB.OUTPUT,
            query: JSON.stringify({
                "contract_code.value": contractCode
            })
        };
        // Log request details
        console.log("Request URL:", url);
        console.log("Request Headers:", headers);
        console.log("Request Body:", body);
        _lib_logger__WEBPACK_IMPORTED_MODULE_0__/* ["default"].log */ .Z.log("Request URL:", url);
        _lib_logger__WEBPACK_IMPORTED_MODULE_0__/* ["default"].log */ .Z.log("Request Headers:", headers);
        _lib_logger__WEBPACK_IMPORTED_MODULE_0__/* ["default"].log */ .Z.log("Request Body:", body);
        const response = await axios__WEBPACK_IMPORTED_MODULE_2__["default"].post(url, body, {
            headers: headers
        });
        // Log the response
        console.log("Response Status:", response.status);
        console.log("Response Data:", response.data);
        _lib_logger__WEBPACK_IMPORTED_MODULE_0__/* ["default"].log */ .Z.log("Response Status:", response.status);
        _lib_logger__WEBPACK_IMPORTED_MODULE_0__/* ["default"].log */ .Z.log("Response Data:", response.data);
        return response.data;
    } catch (error) {
        _lib_logger__WEBPACK_IMPORTED_MODULE_0__/* ["default"].error */ .Z.error(`Error getting contract by contractCode: ${contractCode}`, error);
        throw new Error(`Error getting contract by contractCode: ${contractCode}`);
    }
};
const getOrderByCustomerId = async (customerId, sort = _client_api_endpoints__WEBPACK_IMPORTED_MODULE_6__/* .BIZFLY_CRM_QUERY_PARAMS.SORTED_DESC */ .rB.SORTED_DESC)=>{
    try {
        const url = _client_api_endpoints__WEBPACK_IMPORTED_MODULE_6__/* .BASE_URL */ ._n + _client_api_endpoints__WEBPACK_IMPORTED_MODULE_6__/* .API_ENDPOINTS.BASE_TABLE_FIND */ .Pn.BASE_TABLE_FIND;
        const headers = generateHeaders();
        const body = {
            table: _client_api_endpoints__WEBPACK_IMPORTED_MODULE_6__/* .BIZFLY_CRM_TABLES.ORDER */ .aW.ORDER,
            limit: _client_api_endpoints__WEBPACK_IMPORTED_MODULE_6__/* .BIZFLY_CRM_QUERY_PARAMS.LIMIT */ .rB.LIMIT,
            sort: {
                _id: sort === _client_api_endpoints__WEBPACK_IMPORTED_MODULE_6__/* .BIZFLY_CRM_QUERY_PARAMS.SORTED_DESC */ .rB.SORTED_DESC ? -1 : 1
            },
            output: _client_api_endpoints__WEBPACK_IMPORTED_MODULE_6__/* .BIZFLY_CRM_QUERY_PARAMS.OUTPUT */ .rB.OUTPUT,
            query: {
                "customer.id": customerId
            }
        };
        // Log request details
        console.log("Request URL:", url);
        console.log("Request Headers:", headers);
        console.log("Request Body:", body);
        _lib_logger__WEBPACK_IMPORTED_MODULE_0__/* ["default"].log */ .Z.log("Request URL:", url);
        _lib_logger__WEBPACK_IMPORTED_MODULE_0__/* ["default"].log */ .Z.log("Request Headers:", headers);
        _lib_logger__WEBPACK_IMPORTED_MODULE_0__/* ["default"].log */ .Z.log("Request Body:", body);
        const response = await axios__WEBPACK_IMPORTED_MODULE_2__["default"].post(url, body, {
            headers: headers
        });
        // Log the response
        console.log("Response Status:", response.status);
        console.log("Response Data:", response.data);
        _lib_logger__WEBPACK_IMPORTED_MODULE_0__/* ["default"].log */ .Z.log("Response Status:", response.status);
        _lib_logger__WEBPACK_IMPORTED_MODULE_0__/* ["default"].log */ .Z.log("Response Data:", response.data);
        return response.data;
    } catch (error) {
        _lib_logger__WEBPACK_IMPORTED_MODULE_0__/* ["default"].error */ .Z.error(`Error getting order by customerId: ${customerId}`, error);
        throw new Error(`Error getting order by customerId: ${customerId}`);
    }
};
const getOrderExpiredById = async (orderId)=>{
    try {
        const url = BASE_URL + API_ENDPOINTS.BASE_TABLE_FIND;
        const headers = generateHeaders();
        const body = createQueryParamsOrderExpired(orderId);
        // Log request details
        console.log("Request URL:", url);
        console.log("Request Headers:", headers);
        console.log("Request Body:", body);
        logger.log("Request URL:", url);
        logger.log("Request Headers:", headers);
        logger.log("Request Body:", body);
        const response = await axios.post(url, body, {
            headers: headers
        });
        // Log the response
        console.log("Response Status:", response.status);
        console.log("Response Data:", response.data);
        logger.log("Response Status:", response.status);
        logger.log("Response Data:", response.data);
        return response.data;
    } catch (error) {
        logger.error(`Error getting order by id: ${orderId}`, error);
        throw new Error(`Error getting order by id: ${orderId}`);
    }
};
const getLastVocByCustomer = async (customerId, offsetTime = 0)=>{
    try {
        const url = _client_api_endpoints__WEBPACK_IMPORTED_MODULE_6__/* .BASE_URL */ ._n + _client_api_endpoints__WEBPACK_IMPORTED_MODULE_6__/* .API_ENDPOINTS.BASE_TABLE_FIND */ .Pn.BASE_TABLE_FIND;
        const headers = generateHeaders();
        const body = (0,_utils_bizflycrm_util__WEBPACK_IMPORTED_MODULE_1__/* .createQueryParamsVocsOffsetTime */ .yi)(customerId, offsetTime);
        // Log request details
        console.log("Request URL:", url);
        console.log("Request Headers:", headers);
        console.log("Request Body:", body);
        _lib_logger__WEBPACK_IMPORTED_MODULE_0__/* ["default"].log */ .Z.log("Request URL:", url);
        _lib_logger__WEBPACK_IMPORTED_MODULE_0__/* ["default"].log */ .Z.log("Request Headers:", headers);
        _lib_logger__WEBPACK_IMPORTED_MODULE_0__/* ["default"].log */ .Z.log("Request Body:", body);
        const response = await axios__WEBPACK_IMPORTED_MODULE_2__["default"].post(url, body, {
            headers: headers
        });
        // Log the response
        console.log("Response Status:", response.status);
        console.log("Response Data:", response.data);
        _lib_logger__WEBPACK_IMPORTED_MODULE_0__/* ["default"].log */ .Z.log("Response Status:", response.status);
        _lib_logger__WEBPACK_IMPORTED_MODULE_0__/* ["default"].log */ .Z.log("Response Data:", response.data);
        return response.data;
    } catch (error) {
        _lib_logger__WEBPACK_IMPORTED_MODULE_0__/* ["default"].error */ .Z.error(`Error getting last voc by customerId: ${customerId}`, error);
        throw new Error(`Error getting last voc by customerId: ${customerId}`);
    }
};
const getLastVocByOrderId = async (orderId)=>{
    try {
        const url = BASE_URL + API_ENDPOINTS.BASE_TABLE_FIND;
        const headers = generateHeaders();
        const body = createQueryParamsVocsByOrderId(orderId);
        // Log request details
        console.log("Request URL:", url);
        console.log("Request Headers:", headers);
        console.log("Request Body:", body);
        logger.log("Request URL:", url);
        logger.log("Request Headers:", headers);
        logger.log("Request Body:", body);
        const response = await axios.post(url, body, {
            headers: headers
        });
        // Log the response
        console.log("Response Status:", response.status);
        console.log("Response Data:", response.data);
        logger.log("Response Status:", response.status);
        logger.log("Response Data:", response.data);
        return response.data;
    } catch (error) {
        logger.error(`Error getting last voc by orderId: ${orderId}`, error);
        throw new Error(`Error getting last voc by orderId: ${orderId}`);
    }
};
const postVocs = async (data)=>{
    console.log("postVocs JSON:", data);
    _lib_logger__WEBPACK_IMPORTED_MODULE_0__/* ["default"].log */ .Z.log("postVocs JSON:", data);
    try {
        const url = _client_api_endpoints__WEBPACK_IMPORTED_MODULE_6__/* .BASE_URL */ ._n + _client_api_endpoints__WEBPACK_IMPORTED_MODULE_6__/* .API_ENDPOINTS.BASE_TABLE_UPDATE */ .Pn.BASE_TABLE_UPDATE;
        const headers = generateHeaders();
        const body = data;
        // Log request details
        console.log("Request URL:", url);
        console.log("Request Headers:", headers);
        console.log("Request Body:", body);
        _lib_logger__WEBPACK_IMPORTED_MODULE_0__/* ["default"].log */ .Z.log("Request URL:", url);
        _lib_logger__WEBPACK_IMPORTED_MODULE_0__/* ["default"].log */ .Z.log("Request Headers:", headers);
        _lib_logger__WEBPACK_IMPORTED_MODULE_0__/* ["default"].log */ .Z.log("Request Body:", body);
        const response = await axios__WEBPACK_IMPORTED_MODULE_2__["default"].post(url, body, {
            headers: headers
        });
        // Log the response
        console.log("Response Status:", response.status);
        console.log("Response Data:", response.data);
        _lib_logger__WEBPACK_IMPORTED_MODULE_0__/* ["default"].log */ .Z.log("Response Status:", response.status);
        _lib_logger__WEBPACK_IMPORTED_MODULE_0__/* ["default"].log */ .Z.log("Response Data:", response.data);
        return response.data;
    } catch (error) {
        _lib_logger__WEBPACK_IMPORTED_MODULE_0__/* ["default"].error */ .Z.error(`Error posting vocs: ${data}`, error);
        throw new Error(`Error posting vocs: ${data}`);
    }
};
/**
 * Function for testing purposes
 * @param data
 * @returns
 */ const postVocsTest = async (data)=>{
    console.log("~test postVocsTest JSON:", JSON.stringify(data));
    _lib_logger__WEBPACK_IMPORTED_MODULE_0__/* ["default"].log */ .Z.log("~test postVocsTest JSON:", data);
    try {
        const url = _client_api_endpoints__WEBPACK_IMPORTED_MODULE_6__/* .BASE_URL */ ._n + _client_api_endpoints__WEBPACK_IMPORTED_MODULE_6__/* .API_ENDPOINTS.BASE_TABLE_UPDATE */ .Pn.BASE_TABLE_UPDATE;
        const headers = generateHeaders();
        const body = data;
        // Log request details
        console.log("~test Request URL:", url);
        console.log("~test Request Headers:", headers);
        console.log("~test Request Body:", JSON.stringify(body));
        _lib_logger__WEBPACK_IMPORTED_MODULE_0__/* ["default"].log */ .Z.log("~test Request URL:", url);
        _lib_logger__WEBPACK_IMPORTED_MODULE_0__/* ["default"].log */ .Z.log("~test Request Headers:", headers);
        _lib_logger__WEBPACK_IMPORTED_MODULE_0__/* ["default"].log */ .Z.log("~test Request Body:", body);
        // Save data to a file
        saveVocsDataToFile(data);
        return {
            status: 1
        };
    } catch (error) {
        _lib_logger__WEBPACK_IMPORTED_MODULE_0__/* ["default"].error */ .Z.error(`~test Error posting vocs: ${data}`, error);
        throw new Error(`~test Error posting vocs: ${data}`);
    }
};
// Function to save VOCS data to a file
const saveVocsDataToFile = (data)=>{
    console.log("saveVocsDataToFile:", JSON.stringify(data));
    _lib_logger__WEBPACK_IMPORTED_MODULE_0__/* ["default"].log */ .Z.log("saveVocsDataToFile:", data);
    const dataDir = path__WEBPACK_IMPORTED_MODULE_5___default().join(process.cwd(), "data");
    const filePath = path__WEBPACK_IMPORTED_MODULE_5___default().join(dataDir, "vocs.json");
    try {
        // Ensure the data directory exists
        if (!fs__WEBPACK_IMPORTED_MODULE_4___default().existsSync(dataDir)) {
            fs__WEBPACK_IMPORTED_MODULE_4___default().mkdirSync(dataDir);
            _lib_logger__WEBPACK_IMPORTED_MODULE_0__/* ["default"].log */ .Z.log(`Data directory created at: ${dataDir}`);
        }
        // Ensure the vocs.json file exists
        if (!fs__WEBPACK_IMPORTED_MODULE_4___default().existsSync(filePath)) {
            fs__WEBPACK_IMPORTED_MODULE_4___default().writeFileSync(filePath, JSON.stringify([]));
            _lib_logger__WEBPACK_IMPORTED_MODULE_0__/* ["default"].log */ .Z.log(`vocs.json file created at: ${filePath}`);
        }
        let existingData = [];
        const fileContent = fs__WEBPACK_IMPORTED_MODULE_4___default().readFileSync(filePath, "utf-8");
        if (fileContent) {
            existingData = JSON.parse(fileContent);
        }
        // Prepend the new data to the existing data array
        existingData.unshift(JSON.stringify(data));
        fs__WEBPACK_IMPORTED_MODULE_4___default().writeFileSync(filePath, JSON.stringify(existingData, null, 2));
        _lib_logger__WEBPACK_IMPORTED_MODULE_0__/* ["default"].log */ .Z.log(`Data saved to: ${filePath}`);
    } catch (error) {
        console.error("Error occurred while saving data to file:", error);
        _lib_logger__WEBPACK_IMPORTED_MODULE_0__/* ["default"].error */ .Z.error("Error occurred while saving data to file:", error);
    }
};
// Function to get VOCS data from a file
const getVocsDataFromFile = ()=>{
    const filePath = path__WEBPACK_IMPORTED_MODULE_5___default().join(process.cwd(), "data", "vocs.json");
    if (fs__WEBPACK_IMPORTED_MODULE_4___default().existsSync(filePath)) {
        const fileContent = fs__WEBPACK_IMPORTED_MODULE_4___default().readFileSync(filePath, "utf-8");
        _lib_logger__WEBPACK_IMPORTED_MODULE_0__/* ["default"].log */ .Z.log(`Data retrieved from: ${filePath}`);
        return JSON.parse(fileContent);
    } else {
        _lib_logger__WEBPACK_IMPORTED_MODULE_0__/* ["default"].log */ .Z.log(`File not found: ${filePath}`);
        return [];
    }
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4780:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Pn": () => (/* binding */ API_ENDPOINTS),
/* harmony export */   "_n": () => (/* binding */ BASE_URL),
/* harmony export */   "aW": () => (/* binding */ BIZFLY_CRM_TABLES),
/* harmony export */   "rB": () => (/* binding */ BIZFLY_CRM_QUERY_PARAMS)
/* harmony export */ });
/* unused harmony export API_LOCAL_ENDPOINTS */
const BASE_URL = process.env.BIZFLY_CRM_REST_API_ENDPOINT;
const API_ENDPOINTS = {
    BASE_TABLE_STRUCT: "/_api/base-table/struct",
    BASE_TABLE_FIND: "/_api/base-table/find",
    BASE_TABLE_UPDATE: "/_api/base-table/update"
};
const API_LOCAL_ENDPOINTS = {
    GENERATE_TOKEN: "/api/generate-token",
    VERIFY_RECAPTCHA: "/api/verify-recaptcha",
    GET_CUSTOMER: "/api/get-customer",
    GET_CONTRACT: "/api/get-contract",
    GET_ORDER: "/api/get-order",
    POST_VOCS: "/api/post-vocs",
    POST_SELL_VOCS: "/api/post-sell-vocs",
    POST_PURCHASE_VOCS: "/api/post-purchase-vocs",
    // Test save vocs to local storage
    TEST_SAVE_VOCS: "/api/test/save-vocs",
    TEST_GET_VOCS: "/api/test/get-vocs",
    TEST_CLEAR_VOCS: "/api/test/clear-vocs"
};
const BIZFLY_CRM_TABLES = {
    CUSTOMER: "data_customer",
    CONTRACT: "data_contract",
    ORDER: "data_order",
    VOCS: "data_extra_4"
};
const BIZFLY_CRM_QUERY_PARAMS = {
    SORTED_ASC: "asc",
    SORTED_DESC: "desc",
    OUTPUT: "by-key",
    LIMIT: 1
};


/***/ }),

/***/ 6732:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "It": () => (/* binding */ CASHION_VOC_TIME_DELAY_IN_MILLISECONDS),
/* harmony export */   "qf": () => (/* binding */ USE_ONLY_AUTH_HEADER)
/* harmony export */ });
/* unused harmony exports TOKEN, AUTH_TOKEN_KEY, AUTH_PERMISSIONS, LIMIT, RTL_LANGUAGES, getDirection, CASHION_ORDER_TIME_EXPIRATION_IN_MILLISECONDS, CASHION_REVIEW_OPTIONS, CASHION_SURVEY_SALE_OPTIONS */
const TOKEN = "token";
const AUTH_TOKEN_KEY = "auth_token";
const AUTH_PERMISSIONS = "auth_permissions";
const LIMIT = 10;
const RTL_LANGUAGES = (/* unused pure expression or super */ null && ([
    "ar",
    "he"
]));
function getDirection(language) {
    if (!language) return "ltr";
    return RTL_LANGUAGES.includes(language) ? "rtl" : "ltr";
}
// For test bypass ReCAPTCHA (ex: test localhost on mobile)
const USE_ONLY_AUTH_HEADER = "x-use-only-auth";
const CASHION_VOC_TIME_DELAY_IN_MILLISECONDS = 3 * 60 * 1000; // 3 minutes
const CASHION_ORDER_TIME_EXPIRATION_IN_MILLISECONDS = (/* unused pure expression or super */ null && (30 * 24 * 60 * 60 * 1000)); // 30 days
const CASHION_REVIEW_OPTIONS = (/* unused pure expression or super */ null && ([
    [
        "Sản phẩm",
        "Tư vấn vi\xean",
        "Thời gian giao h\xe0ng",
        "Đ\xf3ng g\xf3i sản phẩm",
        "Chương tr\xecnh khuyến m\xe3i",
        "Kh\xf4ng gian cửa h\xe0ng",
        "Ch\xednh s\xe1ch hậu m\xe3i",
        "Kh\xe1c"
    ],
    [
        "Thời gian giao dịch",
        "Tư vấn vi\xean",
        "Kh\xf4ng gian cửa h\xe0ng",
        "Quy tr\xecnh v\xe0 ch\xednh s\xe1ch",
        "Chương tr\xecnh khuyến m\xe3i",
        "Kh\xe1c"
    ],
    [
        "Sản phẩm",
        "Tư vấn vi\xean",
        "Thời gian giao h\xe0ng",
        "Đ\xf3ng g\xf3i sản phẩm",
        "Chương tr\xecnh khuyến m\xe3i",
        "Kh\xf4ng gian cửa h\xe0ng",
        "Kh\xe1c"
    ]
]));
const CASHION_SURVEY_SALE_OPTIONS = (/* unused pure expression or super */ null && ([
    [
        "Kh\xf4ng c\xf2n nhu cầu",
        "Gi\xe1 th\xe0nh sản phẩm",
        "Nh\xe2n vi\xean tư vấn",
        "Ch\xednh s\xe1ch thu hồi",
        "Kh\xf4ng kịp thời tư vấn",
        "Thời gian giao h\xe0ng",
        "Chưa c\xf3 sản phẩm ph\xf9 hợp",
        "Kh\xe1c"
    ],
    [
        "Kh\xf4ng c\xf2n nhu cầu",
        "Kh\xf4ng đ\xe1p ứng gi\xe1",
        "Nh\xe2n vi\xean tư vấn",
        "Kh\xf4ng đồng \xfd quy tr\xecnh",
        "Kh\xf4ng kịp thời tư vấn",
        "Thời gian giao dịch",
        "Kh\xe1c"
    ]
]));


/***/ }),

/***/ 1019:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var winston__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7773);
/* harmony import */ var winston__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(winston__WEBPACK_IMPORTED_MODULE_0__);
// lib/logger.ts

const logBase = (0,winston__WEBPACK_IMPORTED_MODULE_0__.createLogger)({
    level: "info",
    format: winston__WEBPACK_IMPORTED_MODULE_0__.format.combine(winston__WEBPACK_IMPORTED_MODULE_0__.format.timestamp(), winston__WEBPACK_IMPORTED_MODULE_0__.format.errors({
        stack: true
    }), winston__WEBPACK_IMPORTED_MODULE_0__.format.printf(({ timestamp , level , message , service  })=>{
        return `[${service}] ${process.pid} - ${timestamp} ${level.toUpperCase()} ${message}`;
    }), winston__WEBPACK_IMPORTED_MODULE_0__.format.colorize()),
    defaultMeta: {
        service: "cashion-vote"
    },
    transports: [
        new winston__WEBPACK_IMPORTED_MODULE_0__.transports.File({
            filename: "logs/error.log",
            level: "error",
            maxsize: 10485760,
            maxFiles: 10
        }),
        new winston__WEBPACK_IMPORTED_MODULE_0__.transports.File({
            filename: "logs/combined.log",
            maxsize: 10485760,
            maxFiles: 10
        })
    ]
});
const logMessage = (level, message, ...optionalParams)=>{
    if (typeof message === "object") {
        message = JSON.stringify(message);
    }
    optionalParams = optionalParams.map((param)=>{
        if (typeof param === "object") {
            return JSON.stringify(param);
        }
        return param;
    });
    if (optionalParams.length > 0) {
        message = `${message} ${optionalParams.join(" ")}`;
    }
    logBase.log(level, message);
};
const info = (message, ...optionalParams)=>{
    logMessage("info", message, ...optionalParams);
};
const log = info;
const error = (message, ...optionalParams)=>{
    logMessage("error", message, ...optionalParams);
};
const warn = (message, ...optionalParams)=>{
    logMessage("warn", message, ...optionalParams);
};
const debug = (message, ...optionalParams)=>{
    logMessage("debug", message, ...optionalParams);
};
const logger = {
    log,
    info,
    error,
    warn,
    debug
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (logger);


/***/ }),

/***/ 599:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "yi": () => (/* binding */ createQueryParamsVocsOffsetTime)
/* harmony export */ });
/* unused harmony exports createInputDataVocs, createInputDataSellVocs, createQueryParamsVocsByOrderId, createQueryParamsOrderExpired, getTimeISOString */
/* harmony import */ var _data_client_api_endpoints__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4780);
/* harmony import */ var _lib_constants__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6732);
// src/utils/bizflycrm.util.ts


function createInputDataVocs(input) {
    const { phone , customer , order , rating , saleImproves , note , desireNewPrice , newPrice  } = input;
    let phoneCustomer = phone;
    const fields = [
        {
            key: "danh_gia",
            value: rating
        },
        {
            key: "can_cai_thien",
            value: saleImproves?.join(", ")
        },
        {
            key: "danh_gia_chi_tiet",
            value: note
        }
    ];
    if (customer?.id) {
        fields.push({
            key: "customer",
            value: [
                {
                    value: customer.name?.value,
                    id: customer.id
                }
            ]
        });
        if (customer?.phones?.[0]?.value && phoneCustomer !== customer.phones?.[0]?.value) {
            phoneCustomer = customer.phones?.[0]?.value;
            console.log("update phoneCustomer:", phoneCustomer, ", phone: ", phone);
        }
    }
    if (order?.id) {
        fields.push({
            key: "ma_hoa_don",
            value: [
                {
                    value: order.order_code,
                    id: order.id
                }
            ]
        });
    }
    if (phone) {
        fields.push({
            key: "sdt",
            value: [
                {
                    value: phoneCustomer
                }
            ]
        });
    }
    if (desireNewPrice !== undefined) {
        if (desireNewPrice > -1) {
            fields.push({
                key: "mong_muon_dinh_gia_lai",
                value: [
                    {
                        value: desireNewPrice === 1 ? "c\xf3" : "kh\xf4ng"
                    }
                ]
            });
        }
        if (desireNewPrice === 1 && newPrice) {
            fields.push({
                key: "gia_mong_muon",
                value: newPrice
            });
        }
    }
    return {
        table: BIZFLY_CRM_TABLES.VOCS,
        data: [
            {
                fields: fields
            }
        ]
    };
}
function createInputDataSellVocs(input) {
    console.log("createInputDataSellVocs input:", JSON.stringify(input)); // Log input để debug
    const { billCode , orderId , contractId , rating , saleImproves , note , ref , desireNewPrice , newPrice , customerCode , branchAddress , transactionType , transactionTime  } = input;
    const fields = [
        {
            key: "danh_gia",
            value: rating
        },
        {
            key: "can_cai_thien",
            value: saleImproves?.join(", ")
        },
        {
            key: "danh_gia_chi_tiet",
            value: note
        },
        {
            key: "ref",
            value: ref || ""
        }
    ];
    if (orderId) {
        fields.push({
            key: "id_dh",
            value: orderId
        });
    }
    if (contractId) {
        fields.push({
            key: "id_hd",
            value: contractId
        });
    }
    if (billCode) {
        fields.push({
            key: "hd",
            value: billCode
        });
    }
    if (desireNewPrice !== undefined) {
        if (desireNewPrice > -1) {
            fields.push({
                key: "mong_muon_dinh_gia_lai",
                value: [
                    {
                        value: desireNewPrice === 1 ? "c\xf3" : "kh\xf4ng"
                    }
                ]
            });
        }
        if (desireNewPrice === 1 && newPrice) {
            fields.push({
                key: "gia_mong_muon",
                value: newPrice
            });
        }
    }
    if (customerCode) {
        fields.push({
            key: "ma_kh",
            value: customerCode
        });
    }
    if (branchAddress) {
        fields.push({
            key: "cn1",
            value: branchAddress
        });
    }
    if (transactionType) {
        fields.push({
            key: "lgd",
            value: transactionType
        });
    }
    if (transactionTime) {
        fields.push({
            key: "tgd1",
            value: transactionTime
        });
    }
    return {
        table: BIZFLY_CRM_TABLES.VOCS,
        data: [
            {
                fields: fields
            }
        ]
    };
}
function createQueryParamsVocsOffsetTime(customerId, offset) {
    return {
        table: _data_client_api_endpoints__WEBPACK_IMPORTED_MODULE_0__/* .BIZFLY_CRM_TABLES.VOCS */ .aW.VOCS,
        limit: 1,
        sort: {
            _id: -1
        },
        output: "by-key",
        query: {
            "customer.id": customerId,
            created_at: {
                $gt: getTimeISOString(_lib_constants__WEBPACK_IMPORTED_MODULE_1__/* .CASHION_VOC_TIME_DELAY_IN_MILLISECONDS */ .It * -1)
            }
        },
        select: [
            "_id",
            "customer",
            "created_at"
        ]
    };
}
function createQueryParamsVocsByOrderId(orderId) {
    return {
        table: BIZFLY_CRM_TABLES.VOCS,
        limit: 1,
        sort: {
            _id: -1
        },
        output: "by-key",
        query: {
            "id_dh.id": orderId
        },
        select: [
            "_id",
            "created_at"
        ]
    };
}
function createQueryParamsOrderExpired(orderId) {
    return {
        table: BIZFLY_CRM_TABLES.ORDER,
        limit: 1,
        sort: {
            _id: -1
        },
        output: "by-key",
        query: {
            id: orderId,
            created_at: {
                $lt: getTimeISOString(CASHION_ORDER_TIME_EXPIRATION_IN_MILLISECONDS * -1)
            }
        }
    };
}
function getTimeISOString(offset) {
    const currentTime = new Date();
    const offsetTime = new Date(currentTime.getTime() + offset);
    console.log("currentTime:", currentTime.toISOString());
    console.log("offsetTime:", offsetTime.toISOString());
    return offsetTime.toISOString();
}


/***/ })

};
;