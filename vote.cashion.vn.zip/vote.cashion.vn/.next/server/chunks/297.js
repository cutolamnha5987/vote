"use strict";
exports.id = 297;
exports.ids = [297];
exports.modules = {

/***/ 6297:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ SurveyNewSale)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1527);
/* harmony import */ var _components_SuccessMessage__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7229);
/* harmony import */ var _components_icons_star_icon__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2369);
/* harmony import */ var _components_ui_modal_modal_context__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9021);
/* harmony import */ var _data_client_api_endpoints__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3592);
/* harmony import */ var _lib_constants__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(9346);
/* harmony import */ var _utils_bizflycrm_util__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2218);
/* harmony import */ var next_recaptcha_v3__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7692);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(654);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var next_navigation__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(2889);
/* harmony import */ var next_navigation__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(next_navigation__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(3590);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([next_recaptcha_v3__WEBPACK_IMPORTED_MODULE_6__, react_toastify__WEBPACK_IMPORTED_MODULE_11__]);
([next_recaptcha_v3__WEBPACK_IMPORTED_MODULE_6__, react_toastify__WEBPACK_IMPORTED_MODULE_11__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);













function SurveyNewSale({ token , optionId , isRePrice  }) {
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_9__.useRouter)();
    const searchParams = (0,next_navigation__WEBPACK_IMPORTED_MODULE_8__.useSearchParams)();
    let OPTION_ID = optionId ?? 0;
    const numColumns = _lib_constants__WEBPACK_IMPORTED_MODULE_12__/* .CASHION_REVIEW_OPTIONS */ .td[OPTION_ID].length <= 4 ? 2 : 3;
    const { closeModal  } = (0,_components_ui_modal_modal_context__WEBPACK_IMPORTED_MODULE_3__/* .useModalAction */ .SO)();
    const [loading, setLoading] = (0,react__WEBPACK_IMPORTED_MODULE_10__.useState)(false);
    const [test, setTest] = (0,react__WEBPACK_IMPORTED_MODULE_10__.useState)(false);
    const [orderId, setOrderId] = (0,react__WEBPACK_IMPORTED_MODULE_10__.useState)("");
    const [contractId, setContractId] = (0,react__WEBPACK_IMPORTED_MODULE_10__.useState)("");
    const [billCode, setBillCode] = (0,react__WEBPACK_IMPORTED_MODULE_10__.useState)("");
    const [customerCode, setCustomerCode] = (0,react__WEBPACK_IMPORTED_MODULE_10__.useState)("");
    const [branchAddress, setBranchAddress] = (0,react__WEBPACK_IMPORTED_MODULE_10__.useState)("");
    const [transactionType, setTransactionType] = (0,react__WEBPACK_IMPORTED_MODULE_10__.useState)("");
    const [transactionTime, setTransactionTime] = (0,react__WEBPACK_IMPORTED_MODULE_10__.useState)("");
    const [rating, setRating] = (0,react__WEBPACK_IMPORTED_MODULE_10__.useState)(0);
    const [options, setOptions] = (0,react__WEBPACK_IMPORTED_MODULE_10__.useState)([]);
    const [note, setNote] = (0,react__WEBPACK_IMPORTED_MODULE_10__.useState)("");
    const [recommendation, setRecommendation] = (0,react__WEBPACK_IMPORTED_MODULE_10__.useState)(""); // Thêm trạng thái cho recommendation
    const [isSubmitted, setIsSubmitted] = (0,react__WEBPACK_IMPORTED_MODULE_10__.useState)(false);
    const { executeRecaptcha  } = (0,next_recaptcha_v3__WEBPACK_IMPORTED_MODULE_6__.useReCaptcha)();
    const [desireNewPrice, setDesireNewPrice] = (0,react__WEBPACK_IMPORTED_MODULE_10__.useState)(-1);
    const [newPrice, setNewPrice] = (0,react__WEBPACK_IMPORTED_MODULE_10__.useState)("");
    const inputNewPriceRef = (0,react__WEBPACK_IMPORTED_MODULE_10__.useRef)(null);
    const getColSpanClass = (index, length)=>{
        if (index !== length - 1) {
            return "";
        }
        let colSpanClass = "";
        if (index % 2 === 0) {
            colSpanClass += "col-span-2 ";
        }
        if (index % 3 === 0) {
            colSpanClass += "md:col-span-3";
        } else if (index % 3 === 1) {
            colSpanClass += "md:col-span-2";
        }
        return colSpanClass.trim();
    };
    const formatNumber = (value)=>{
        return value.toLocaleString("en-US");
    };
    const parseNumber = (value)=>{
        return parseInt(value.replace(/,/g, ""), 10);
    };
    const handleNewPriceChange = (e)=>{
        const value = e.target.value;
        const numericValue = parseNumber(value);
        setNewPrice(numericValue || "");
    };
    const handleYesClick = (e)=>{
        e.preventDefault();
        setDesireNewPrice(1);
        if (inputNewPriceRef.current) {
            inputNewPriceRef.current.focus();
        }
    };
    const handleNoClick = (e)=>{
        e.preventDefault();
        setDesireNewPrice(0);
    };
    const handleCheckboxChange = (option)=>{
        setOptions((prevOptions)=>prevOptions.includes(option) ? prevOptions.filter((opt)=>opt !== option) : [
                ...prevOptions,
                option
            ]);
    };
    const handleRecommendationChange = (value)=>{
        setRecommendation(value); // Cập nhật giá trị recommendation
    };
    const submitDataVocs = async (data)=>{
        console.log("Submitting data:", JSON.stringify(data)); // Log dữ liệu gửi
        try {
            const response = await fetch(_data_client_api_endpoints__WEBPACK_IMPORTED_MODULE_4__/* .API_LOCAL_ENDPOINTS.POST_SELL_VOCS */ .LI.POST_SELL_VOCS, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    Authorization: `Bearer ${token}`
                },
                body: JSON.stringify({
                    ...data,
                    test,
                    billCode,
                    orderId,
                    recaptchaToken: await executeRecaptcha("onSubmitDataVocs")
                })
            });
            if (!response.ok) {
                throw new Error("Failed to post VOCS");
            }
            const responseData = await response.json();
            return responseData;
        } catch (error) {
            console.error("Error create VOCS:", error);
        }
    };
    const handleSubmit = async (e)=>{
        e.preventDefault();
        if (OPTION_ID === 0 && !orderId) {
            react_toastify__WEBPACK_IMPORTED_MODULE_11__.toast.warn("Kh\xf4ng c\xf3 th\xf4ng tin đơn h\xe0ng ");
            return;
        }
        if (OPTION_ID === 1 && !contractId) {
            react_toastify__WEBPACK_IMPORTED_MODULE_11__.toast.warn("Kh\xf4ng c\xf3 th\xf4ng tin hợp đồng");
            return;
        }
        if (transactionTime) {
            const [day, month, year] = transactionTime.split("/");
            const transactionDate = new Date(parseInt(year), parseInt(month) - 1, parseInt(day));
            if (!isNaN(transactionDate.getTime())) {
                const currentDate = new Date();
                const thirtyDaysInMs = 30 * 24 * 60 * 60 * 1000;
                if (currentDate.getTime() - transactionDate.getTime() > thirtyDaysInMs) {
                    react_toastify__WEBPACK_IMPORTED_MODULE_11__.toast.warn("Đ\xe3 qu\xe1 thời hạn đ\xe1nh gi\xe1 cho giao dịch");
                    return;
                }
            }
        }
        if (rating === 0) {
            react_toastify__WEBPACK_IMPORTED_MODULE_11__.toast.warn("Qu\xfd kh\xe1ch vui l\xf2ng điền th\xf4ng tin");
            return;
        }
        setLoading(true);
        const inputData = (0,_utils_bizflycrm_util__WEBPACK_IMPORTED_MODULE_5__/* .createInputDataSellVocs */ .lW)({
            billCode,
            orderId,
            contractId,
            rating,
            saleImproves: options,
            note,
            ref: recommendation,
            ...OPTION_ID === 1 && {
                desireNewPrice,
                newPrice,
                customerCode,
                branchAddress,
                transactionType,
                transactionTime
            }
        });
        try {
            let response = await submitDataVocs(inputData);
            if (response?.status === 1) {
                setIsSubmitted(true);
            } else if (response?.status === 2) {
                console.warn("Error submitting data:", response);
                react_toastify__WEBPACK_IMPORTED_MODULE_11__.toast.warn("Qu\xfd kh\xe1ch đ\xe3 đ\xe1nh gi\xe1, xin ch\xe2n th\xe0nh cảm ơn.");
            } else if (response?.status === 3) {
                console.warn("Error submitting data:", response);
                react_toastify__WEBPACK_IMPORTED_MODULE_11__.toast.warn("Đ\xe3 qu\xe1 thời hạn đ\xe1nh gi\xe1 cho giao dịch");
            } else {
                console.warn("Error submitting data:", response);
                react_toastify__WEBPACK_IMPORTED_MODULE_11__.toast.warn("Lỗi kết nối. Vui l\xf2ng thử lại sau.");
            }
        } catch (error) {
            console.error("Error submitting data:", error);
        } finally{
            setLoading(false);
            closeModal();
        }
    };
    (0,react__WEBPACK_IMPORTED_MODULE_10__.useEffect)(()=>{
        const utmSource = searchParams.get("utm_source");
        const utmMId = searchParams.get("utm_id");
        const utmCampaign = searchParams.get("utm_campaign");
        const utmMedium = searchParams.get("utm_medium");
        const utmTerm = searchParams.get("utm_term");
        const utmContent = searchParams.get("utm_content");
        if (utmSource) setBillCode(utmSource);
        if (utmMId) {
            if (OPTION_ID === 0) {
                setOrderId(utmMId);
            } else if (OPTION_ID === 1) {
                setContractId(utmMId);
            }
        }
        if (utmCampaign) setBranchAddress(utmCampaign);
        if (utmMedium) setCustomerCode(utmMedium);
        if (utmTerm) setTransactionType(utmTerm);
        if (utmContent) setTransactionTime(utmContent);
    }, [
        OPTION_ID,
        searchParams
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_10__.useEffect)(()=>{
        if (router.isReady) {
            const { test  } = router.query;
            setTest(test === "true");
        }
    }, [
        router.isReady,
        router.query
    ]);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "cashion-vote-container",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: `cashion-vote-body container mx-auto py-4 md:py-6 ${isSubmitted ? "mt-8" : ""}`,
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "flex justify-center",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                        href: "https://cashion.vn",
                        target: "_blank",
                        rel: "noopener noreferrer",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_7___default()), {
                            src: "/images/logo-cashion.png",
                            alt: "Cashion Logo",
                            width: isSubmitted ? 160 : 120,
                            height: isSubmitted ? 50 : 40
                        })
                    })
                }),
                isSubmitted ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_SuccessMessage__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {}) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                    onSubmit: handleSubmit,
                    className: "max-w-2xl mx-auto px-2 py-6 md:p-8 rounded-lg",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "mb-4 md:mb-6",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: "cashion-vote_label font-medium text-[0.9rem] md:text-base tracking-[-0.06rem] md:tracking-tighter flex justify-center text-center",
                                    children: "Đ\xe1nh gi\xe1 độ h\xe0i l\xf2ng của Qu\xfd kh\xe1ch về lần sử dụng dịch vụ tại Cashion"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "flex items-center justify-center space-x-3 mt-2",
                                    children: [
                                        1,
                                        2,
                                        3,
                                        4,
                                        5
                                    ].map((star)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                            type: "button",
                                            onClick: ()=>setRating(star),
                                            className: `text-6xl appearance-none ${rating >= star ? "text-[#E07E00]" : "text-gray-200"}`,
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_icons_star_icon__WEBPACK_IMPORTED_MODULE_2__/* .StarIcon */ .r, {
                                                className: "h-10 w-10 md:h-12 md:w-12"
                                            })
                                        }, star))
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "mb-4 md:mb-6",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: "cashion-vote_label font-medium flex justify-center text-center tracking-tighter",
                                    children: "Vấn đề Qu\xfd kh\xe1ch đang gặp phải tại Cashion"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: `mt-2 grid grid-cols-2 md:grid-cols-${numColumns} gap-3`,
                                    children: _lib_constants__WEBPACK_IMPORTED_MODULE_12__/* .CASHION_REVIEW_OPTIONS */ .td[OPTION_ID].map((option, index, array)=>{
                                        const colSpanClass = getColSpanClass(index, array.length);
                                        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                            className: `flex items-center justify-center text-center text-xs md:text-[0.9rem] cursor-pointer border border-gray-400 rounded-md px-0 py-2 ${colSpanClass} ${options.includes(option) ? "text-white bg-[#E07E00]" : "text-gray-500 bg-white"}`,
                                            onClick: (e)=>{
                                                e.preventDefault();
                                                handleCheckboxChange(option);
                                            },
                                            children: option
                                        }, option);
                                    })
                                })
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "mt-4",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: "cashion-vote_label font-medium flex justify-center text-center tracking-tighter",
                                children: "Qu\xfd kh\xe1ch c\xf3 sẵn l\xf2ng giới thiệu Cashion đến người th\xe2n, bạn b\xe8 kh\xf4ng?"
                            })
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "mt-2 flex justify-center space-x-4",
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("label", {
                                    className: "flex items-center",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                            type: "radio",
                                            name: "recommendation",
                                            value: "C\xf3",
                                            onChange: (e)=>handleRecommendationChange(e.target.value),
                                            className: "mr-2"
                                        }),
                                        "C\xf3"
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("label", {
                                    className: "flex items-center",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                            type: "radio",
                                            name: "recommendation",
                                            value: "Kh\xf4ng",
                                            onChange: (e)=>handleRecommendationChange(e.target.value),
                                            className: "mr-2"
                                        }),
                                        "Kh\xf4ng"
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: `${isRePrice ? "mb-2 md:mb-6" : "mb-4 md:mb-6"}`,
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                    htmlFor: "note",
                                    className: "cashion-vote_label font-medium hidden",
                                    children: "Đ\xe1nh gi\xe1 kh\xe1c về chất lượng dịch vụ tại Cashion"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("textarea", {
                                    id: "note",
                                    value: note,
                                    onChange: (e)=>setNote(e.target.value),
                                    rows: isRePrice ? 2 : 5,
                                    className: "placeholder-gray-400 bg-opacity-70 mt-1 block w-full p-2 pl-4 md:p-3 border border-gray-400 bg-gray-200 rounded-md shadow-sm focus:ring-yellow-600 focus:border-yellow-600 text-xs md:text-sm",
                                    placeholder: "Đ\xe1nh gi\xe1 chi tiết"
                                })
                            ]
                        }),
                        isRePrice && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "mb-4 md:mb-6",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                    htmlFor: "new-price-wrapper",
                                    className: "cashion-vote_label font-medium flex justify-center text-center",
                                    children: "Qu\xfd kh\xe1ch mong muốn định gi\xe1 lại sản phẩm"
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "flex justify-center space-x-4",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                            className: `w-20 flex items-center justify-center text-center border border-gray-400 rounded-md text-sm px-0 py-1 ${desireNewPrice === 1 ? "text-white bg-[#E07E00]" : "text-gray-500 bg-white"}`,
                                            onClick: handleYesClick,
                                            children: "C\xf3"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                            className: `w-20 flex items-center justify-center text-center border border-gray-400 rounded-md text-sm px-0 py-1 ${desireNewPrice === 0 ? "text-white bg-[#E07E00]" : "text-gray-500 bg-white"}`,
                                            onClick: handleNoClick,
                                            children: "Kh\xf4ng"
                                        })
                                    ]
                                }),
                                desireNewPrice === 1 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "mt-2 flex justify-center",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                        type: "text",
                                        id: "new-price",
                                        value: newPrice !== "" ? formatNumber(newPrice) : "",
                                        onChange: handleNewPriceChange,
                                        ref: inputNewPriceRef,
                                        className: "w-60 bg-gray-50 border-1 border-gray-300 text-center text-gray-900 text-sm rounded-lg focus:ring-yellow-600 focus:border-yellow-600 block px-4 py-1 md:py-2 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-yellow-500 dark:focus:border-yellow-500",
                                        placeholder: ""
                                    })
                                })
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                type: "submit",
                                disabled: loading,
                                className: "font-bold uppercase py-1 px-2 border-2 text-md rounded-md text-yellow-600 border-yellow-600 hover:bg-white hover:text-yellow-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 block mx-auto w-60",
                                children: "Gửi đ\xe1nh gi\xe1"
                            })
                        })
                    ]
                })
            ]
        })
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;