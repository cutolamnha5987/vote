"use strict";
exports.id = 344;
exports.ids = [344];
exports.modules = {

/***/ 6436:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1527);

const CheckIcon = ({ width =24 , height =24 , ...props })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
        width: width,
        height: height,
        viewBox: "0 0 24 24",
        fill: "none",
        stroke: "currentColor",
        ...props,
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
            d: "M20 6L9 17L4 12",
            strokeWidth: "2",
            strokeLinecap: "round",
            strokeLinejoin: "round"
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CheckIcon);


/***/ }),

/***/ 102:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "i": () => (/* binding */ SpinnerLoader)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1527);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_1__);



const Spinner = (props)=>{
    const { className , showText =true , text ="Loading" , simple  } = props;
    return /*#__PURE__*/ _jsx(_Fragment, {
        children: simple ? /*#__PURE__*/ _jsx("span", {
            className: cn(className, styles.simple_loading)
        }) : /*#__PURE__*/ _jsxs("span", {
            className: cn("flex h-screen w-full flex-col items-center justify-center", className),
            children: [
                /*#__PURE__*/ _jsx("span", {
                    className: styles.loading
                }),
                showText && /*#__PURE__*/ _jsx("h3", {
                    className: "text-lg font-semibold italic text-body",
                    children: text
                })
            ]
        })
    });
};
const SpinnerLoader = (props)=>{
    const { className  } = props;
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
        className: classnames__WEBPACK_IMPORTED_MODULE_1___default()("inline-flex h-5 w-5 animate-spin rounded-full border-2 border-t-2 border-transparent border-t-accent", className)
    });
};
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (Spinner)));


/***/ })

};
;