"use strict";
exports.id = 336;
exports.ids = [336];
exports.modules = {

/***/ 336:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _token__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6521);
// utils/middleware.ts

const secretKey = process.env.SECRET_KEY;
const authMiddleware = (handler)=>{
    return async (req, res)=>{
        const authorizationHeader = req.headers.authorization;
        if (!authorizationHeader) {
            return res.status(401).json({
                message: "Unauthorized"
            });
        }
        const token = authorizationHeader.split(" ")[1];
        if (!(0,_token__WEBPACK_IMPORTED_MODULE_0__/* .verifyToken */ .W)(token, secretKey)) {
            return res.status(401).json({
                message: "Unauthorized"
            });
        }
        // Proceed with the handler if verification is successful
        return handler(req, res);
    };
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (authMiddleware);


/***/ }),

/***/ 6521:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "R": () => (/* binding */ generateToken),
/* harmony export */   "W": () => (/* binding */ verifyToken)
/* harmony export */ });
/* harmony import */ var crypto__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6113);
/* harmony import */ var crypto__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(crypto__WEBPACK_IMPORTED_MODULE_0__);
// utils/token.ts

const generateToken = (secretKey)=>{
    const original = crypto__WEBPACK_IMPORTED_MODULE_0___default().randomBytes(16).toString("hex");
    const timestamp = Date.now(); // current time in milliseconds
    const hash = crypto__WEBPACK_IMPORTED_MODULE_0___default().createHmac("sha256", secretKey).update(`${original}:${timestamp}`).digest("hex");
    return `${hash}:${original}:${timestamp}`;
};
const verifyToken = (token, secretKey)=>{
    const [hash, original, timestamp] = token.split(":");
    if (!hash || !original || !timestamp) {
        return false;
    }
    const currentTimestamp = Date.now();
    const tokenTimestamp = parseInt(timestamp, 10);
    // Check if the token is older than 1 hour (3600000 milliseconds)
    if (currentTimestamp - tokenTimestamp > 3600000) {
        return false;
    }
    const expectedHash = crypto__WEBPACK_IMPORTED_MODULE_0___default().createHmac("sha256", secretKey).update(`${original}:${timestamp}`).digest("hex");
    return hash === expectedHash;
};


/***/ })

};
;