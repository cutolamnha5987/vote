"use strict";
exports.id = 231;
exports.ids = [231];
exports.modules = {

/***/ 7229:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1527);

const SuccessMessage = ()=>{
    const defaultStyle = {
        fontFamily: "PNJ-Roman",
        fontWeight: 100
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        style: defaultStyle,
        className: "container mt-6 md:mt-8 mx-auto p-3 md:p-6 max-w-2xl rounded-lg",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "font-bold mb-6 md:mb-8 text-base md:text-xl text-center text-yellow-600",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        children: "Ch\xe2n th\xe0nh cảm ơn Qu\xfd kh\xe1ch"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        children: "đ\xe3 d\xe0nh thời gian đ\xe1nh gi\xe1 chất lượng dịch vụ"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        children: "tại Cashion"
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "mb-6 md:mb-8 text-center",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                    className: "text-base md:text-xl font-medium text-gray-500 tracking-tighter",
                    children: "Mọi đ\xe1nh gi\xe1 từ Qu\xfd kh\xe1ch Cashion lu\xf4n tr\xe2n trọng v\xe0 ghi nhận để cải thiện nhằm phục vụ Qu\xfd kh\xe1ch tốt hơn"
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "referral-box text-center mt-6",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                        href: "https://cashion.vn/referral/?utm_source=zalo&utm_medium=referral&utm_campaign=PFM_CAS_CASHION_CTM_VOCS&utm_content=vocs_sau_ban_hang",
                        target: "_blank",
                        rel: "noopener noreferrer",
                        className: "inline-block px-4 py-2 border-2 border-yellow-600 rounded-full font-bold text-yellow-600 hover:bg-white focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-yellow-500 mb-4",
                        children: "Giới thiệu bạn mới – Nhận qu\xe0 liền tay"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex justify-center gap-2 flex-nowrap overflow-x-auto mb-5",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                href: "https://cashion.vn",
                                className: "border px-4 py-2 rounded-full text-gray-400 border-gray-300 hover:border-black hover:text-black whitespace-nowrap",
                                children: "Website"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                href: "https://zalo.me/2408519735788804496",
                                className: "border px-4 py-2 rounded-full text-gray-400 border-gray-300 hover:border-black hover:text-black whitespace-nowrap",
                                children: "Zalo OA"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                href: "https://www.facebook.com/Cashion.store/",
                                className: "border px-4 py-2 rounded-full text-gray-400 border-gray-300 hover:border-black hover:text-black whitespace-nowrap",
                                children: "Fanpage"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                href: "tel:1900886688",
                                className: "border px-4 py-2 rounded-full text-gray-400 border-gray-300 hover:border-black hover:text-black whitespace-nowrap",
                                children: "Hotline"
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SuccessMessage);


/***/ }),

/***/ 2369:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "r": () => (/* binding */ StarIcon)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1527);

const StarIcon = (props)=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        viewBox: "0 0 25.056 24",
        ...props,
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
            "data-name": "Group 36413",
            fill: "currentColor",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                id: "Path_22667",
                "data-name": "Path 22667",
                d: "M19.474,34.679l-6.946-4.346L5.583,34.679a.734.734,0,0,1-1.1-.8L6.469,25.93.263,20.668a.735.735,0,0,1,.421-1.3l8.1-.566,3.064-7.6a.765.765,0,0,1,1.362,0l3.064,7.6,8.1.566a.735.735,0,0,1,.421,1.3L18.588,25.93l1.987,7.949a.734.734,0,0,1-1.1.8Z",
                transform: "translate(0 -10.792)"
            })
        })
    });
};


/***/ }),

/***/ 2218:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "P5": () => (/* binding */ createInputDataVocs),
/* harmony export */   "lW": () => (/* binding */ createInputDataSellVocs)
/* harmony export */ });
/* unused harmony exports createQueryParamsVocsOffsetTime, createQueryParamsVocsByOrderId, createQueryParamsOrderExpired, getTimeISOString */
/* harmony import */ var _data_client_api_endpoints__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3592);
// src/utils/bizflycrm.util.ts


function createInputDataVocs(input) {
    const { phone , customer , order , rating , saleImproves , note , desireNewPrice , newPrice  } = input;
    let phoneCustomer = phone;
    const fields = [
        {
            key: "danh_gia",
            value: rating
        },
        {
            key: "can_cai_thien",
            value: saleImproves?.join(", ")
        },
        {
            key: "danh_gia_chi_tiet",
            value: note
        }
    ];
    if (customer?.id) {
        fields.push({
            key: "customer",
            value: [
                {
                    value: customer.name?.value,
                    id: customer.id
                }
            ]
        });
        if (customer?.phones?.[0]?.value && phoneCustomer !== customer.phones?.[0]?.value) {
            phoneCustomer = customer.phones?.[0]?.value;
            console.log("update phoneCustomer:", phoneCustomer, ", phone: ", phone);
        }
    }
    if (order?.id) {
        fields.push({
            key: "ma_hoa_don",
            value: [
                {
                    value: order.order_code,
                    id: order.id
                }
            ]
        });
    }
    if (phone) {
        fields.push({
            key: "sdt",
            value: [
                {
                    value: phoneCustomer
                }
            ]
        });
    }
    if (desireNewPrice !== undefined) {
        if (desireNewPrice > -1) {
            fields.push({
                key: "mong_muon_dinh_gia_lai",
                value: [
                    {
                        value: desireNewPrice === 1 ? "c\xf3" : "kh\xf4ng"
                    }
                ]
            });
        }
        if (desireNewPrice === 1 && newPrice) {
            fields.push({
                key: "gia_mong_muon",
                value: newPrice
            });
        }
    }
    return {
        table: _data_client_api_endpoints__WEBPACK_IMPORTED_MODULE_0__/* .BIZFLY_CRM_TABLES.VOCS */ .aW.VOCS,
        data: [
            {
                fields: fields
            }
        ]
    };
}
function createInputDataSellVocs(input) {
    console.log("createInputDataSellVocs input:", JSON.stringify(input)); // Log input để debug
    const { billCode , orderId , contractId , rating , saleImproves , note , ref , desireNewPrice , newPrice , customerCode , branchAddress , transactionType , transactionTime  } = input;
    const fields = [
        {
            key: "danh_gia",
            value: rating
        },
        {
            key: "can_cai_thien",
            value: saleImproves?.join(", ")
        },
        {
            key: "danh_gia_chi_tiet",
            value: note
        },
        {
            key: "ref",
            value: ref || ""
        }
    ];
    if (orderId) {
        fields.push({
            key: "id_dh",
            value: orderId
        });
    }
    if (contractId) {
        fields.push({
            key: "id_hd",
            value: contractId
        });
    }
    if (billCode) {
        fields.push({
            key: "hd",
            value: billCode
        });
    }
    if (desireNewPrice !== undefined) {
        if (desireNewPrice > -1) {
            fields.push({
                key: "mong_muon_dinh_gia_lai",
                value: [
                    {
                        value: desireNewPrice === 1 ? "c\xf3" : "kh\xf4ng"
                    }
                ]
            });
        }
        if (desireNewPrice === 1 && newPrice) {
            fields.push({
                key: "gia_mong_muon",
                value: newPrice
            });
        }
    }
    if (customerCode) {
        fields.push({
            key: "ma_kh",
            value: customerCode
        });
    }
    if (branchAddress) {
        fields.push({
            key: "cn1",
            value: branchAddress
        });
    }
    if (transactionType) {
        fields.push({
            key: "lgd",
            value: transactionType
        });
    }
    if (transactionTime) {
        fields.push({
            key: "tgd1",
            value: transactionTime
        });
    }
    return {
        table: _data_client_api_endpoints__WEBPACK_IMPORTED_MODULE_0__/* .BIZFLY_CRM_TABLES.VOCS */ .aW.VOCS,
        data: [
            {
                fields: fields
            }
        ]
    };
}
function createQueryParamsVocsOffsetTime(customerId, offset) {
    return {
        table: BIZFLY_CRM_TABLES.VOCS,
        limit: 1,
        sort: {
            _id: -1
        },
        output: "by-key",
        query: {
            "customer.id": customerId,
            created_at: {
                $gt: getTimeISOString(CASHION_VOC_TIME_DELAY_IN_MILLISECONDS * -1)
            }
        },
        select: [
            "_id",
            "customer",
            "created_at"
        ]
    };
}
function createQueryParamsVocsByOrderId(orderId) {
    return {
        table: BIZFLY_CRM_TABLES.VOCS,
        limit: 1,
        sort: {
            _id: -1
        },
        output: "by-key",
        query: {
            "id_dh.id": orderId
        },
        select: [
            "_id",
            "created_at"
        ]
    };
}
function createQueryParamsOrderExpired(orderId) {
    return {
        table: BIZFLY_CRM_TABLES.ORDER,
        limit: 1,
        sort: {
            _id: -1
        },
        output: "by-key",
        query: {
            id: orderId,
            created_at: {
                $lt: getTimeISOString(CASHION_ORDER_TIME_EXPIRATION_IN_MILLISECONDS * -1)
            }
        }
    };
}
function getTimeISOString(offset) {
    const currentTime = new Date();
    const offsetTime = new Date(currentTime.getTime() + offset);
    console.log("currentTime:", currentTime.toISOString());
    console.log("offsetTime:", offsetTime.toISOString());
    return offsetTime.toISOString();
}


/***/ }),

/***/ 404:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "d": () => (/* binding */ getServerSidePropsWithToken)
/* harmony export */ });
/* harmony import */ var next_i18next_serverSideTranslations__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5460);
/* harmony import */ var next_i18next_serverSideTranslations__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_i18next_serverSideTranslations__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _token__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5770);


const getServerSidePropsWithToken = async ({ locale , params  })=>{
    // console.log('locale', locale);
    // console.log('params', params);
    const secretKey = process.env.SECRET_KEY;
    const token = (0,_token__WEBPACK_IMPORTED_MODULE_1__/* .generateToken */ .R)(secretKey);
    console.log(`secretKey: ${secretKey} | token: ${token}`);
    return {
        props: {
            token,
            ...await (0,next_i18next_serverSideTranslations__WEBPACK_IMPORTED_MODULE_0__.serverSideTranslations)(locale, [
                "common",
                "faq"
            ])
        }
    };
};


/***/ })

};
;