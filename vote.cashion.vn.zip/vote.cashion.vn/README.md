## Description
This project allows customers to submit reviews through the BizflyCRM platform.

## Installation

```bash
$ pnpm install
```

## Running the app

```bash
# development
$ pnpm dev

# production mode
$ pnpm start
```

