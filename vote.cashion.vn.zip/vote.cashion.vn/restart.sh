#!/bin/bash

# Di chuyển vào thư mục dự án (thay đường dẫn này bằng thư mục đúng trên server)
cd /vote.cashion.vn

# Cài lại các dependencies và build lại ứng dụng
pnpm install --prod
pnpm build

# Restart ứng dụng bằng PM2 (thay "your-app-name" bằng tên đúng của ứng dụng)
pm2 restart vote.cashion.vn

# In log để biết quá trình hoàn tất (đảm bảo đường dẫn log đúng)
echo "Ứng dụng đã được build lại và khởi động lại lúc $(date)" >> /vote.cashion.vn/restart.log
